Public Class MainForm

    Private Disk0 As APEFileClass = Nothing
    Private Disk1 As APEFileClass = Nothing
    Private Disk2 As APEFileClass = Nothing
    Private Disk3 As APEFileClass = Nothing

#Region " Startup and Shutdown "
    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblFilename0.Text = ""
        lblFilename1.Text = ""
        lblFilename2.Text = ""
        lblFilename3.Text = ""
        lblSize0.Text = ""
        lblSize1.Text = ""
        lblSize2.Text = ""
        lblSize3.Text = ""

        ' Get a list of serial port names.
        With cboCOMPort
            Dim ports As String() = System.IO.Ports.SerialPort.GetPortNames
            For Each portname As String In ports
                .Items.Add(portname)
            Next portname

            'If .Items.Count > 0 Then
            '    .Text = .Items(0).ToString
            'End If
        End With

        cboBaudRate.Text = "19200"
        cboParity.Text = "None"
        'cboParity.Enabled = False
        cboDataBits.Text = "8"
        'cboDataBits.Enabled = False
        cboStopBits.Text = "1"
        cboHandshaking.Text = "RTS"

        lblTrackData0.Text = ""
        lblSectorData0.Text = ""
        lblReadData0.Text = ChrW(&H25CF) ' Unicode: Black Circle
        lblReadData0.ForeColor = Color.Black
        lblWriteData0.Text = ChrW(&H25CF)
        lblWriteData0.ForeColor = Color.Black

        lblTrackData1.Text = ""
        lblSectorData1.Text = ""
        lblReadData1.Text = ChrW(&H25CF) ' Unicode: Black Circle
        lblReadData1.ForeColor = Color.Black
        lblWriteData1.Text = ChrW(&H25CF)
        lblWriteData1.ForeColor = Color.Black

        lblTrackData2.Text = ""
        lblSectorData2.Text = ""
        lblReadData2.Text = ChrW(&H25CF) ' Unicode: Black Circle
        lblReadData2.ForeColor = Color.Black
        lblWriteData2.Text = ChrW(&H25CF)
        lblWriteData2.ForeColor = Color.Black

        lblTrackData3.Text = ""
        lblSectorData3.Text = ""
        lblReadData3.Text = ChrW(&H25CF) ' Unicode: Black Circle
        lblReadData3.ForeColor = Color.Black
        lblWriteData3.Text = ChrW(&H25CF)
        lblWriteData3.ForeColor = Color.Black

    End Sub

    Private Sub MainForm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Select Case e.CloseReason
            Case CloseReason.ApplicationExitCall
                'MsgBox("CloseReason.ApplicationExitCall.")
            Case CloseReason.FormOwnerClosing
                'MsgBox("CloseReason.FormOwnerClosing")
            Case CloseReason.MdiFormClosing
                'MsgBox("CloseReason.MdiFormClosing")
            Case CloseReason.None
                'MsgBox("CloseReason.None")
            Case CloseReason.TaskManagerClosing
                'MsgBox("CloseReason.TaskManagerClosing")
            Case CloseReason.UserClosing
                'MsgBox("CloseReason.UserClosing")

                'Debug.Print(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name & ": Closing")

                e.Cancel = (MsgBox("Do you want to close?", MsgBoxStyle.Question Or MsgBoxStyle.YesNo Or MsgBoxStyle.DefaultButton2, Me.Text) = MsgBoxResult.No)
            Case CloseReason.WindowsShutDown
                'MsgBox("CloseReason.WindowsShutDown")
        End Select

        ' No point in continuing
        If e.Cancel Then Exit Sub

        SelectedDisk = Nothing
        If Disk0 IsNot Nothing Then Disk0.Close()
        If Disk1 IsNot Nothing Then Disk1.Close()
        If Disk2 IsNot Nothing Then Disk2.Close()
        If Disk3 IsNot Nothing Then Disk3.Close()

        With SerialPort1
            If .IsOpen Then
                .Close()
            End If
        End With
    End Sub
#End Region

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew0.Click, btnNew1.Click, btnNew2.Click, btnNew3.Click
        Dim btnNew As System.Windows.Forms.Button = CType(sender, System.Windows.Forms.Button)
        Select Case btnNew.Name
            Case btnNew0.Name
                NewFileDialog.FileName = "Untitled_0.ape"
            Case btnNew1.Name
                NewFileDialog.FileName = "Untitled_1.ape"
            Case btnNew2.Name
                NewFileDialog.FileName = "Untitled_2.ape"
            Case btnNew3.Name
                NewFileDialog.FileName = "Untitled_3.ape"
        End Select
        Select Case NewFileDialog.ShowDialog(Me)
            Case Windows.Forms.DialogResult.Cancel
            Case Windows.Forms.DialogResult.OK
                Dim DoFormat As Boolean = False
                If My.Computer.FileSystem.FileExists(NewFileDialog.FileName) Then
                    ' File already exists - overwrite?
                    Select Case MsgBox(NewFileDialog.FileName & " already exists." & vbCrLf & "Do you want to replace it?", MsgBoxStyle.YesNo Or MsgBoxStyle.Exclamation Or MsgBoxStyle.DefaultButton2, Me.Text)
                        Case MsgBoxResult.No
                        Case MsgBoxResult.Yes
                            DoFormat = True
                    End Select
                Else
                    DoFormat = True
                End If
                If DoFormat Then
                    Select Case btnNew.Name
                        Case btnNew0.Name
                            Disk0 = New APEFileClass(NewFileDialog.FileName, CUShort(IIf(SectorSizeForm.ShowDialog() = Windows.Forms.DialogResult.Yes, 128, 512)))
                            lblTrackData0.Text = ""
                            lblSectorData0.Text = ""
                            lblReadData0.ForeColor = Color.Black
                            lblWriteData0.ForeColor = Color.Black
                            With Disk0
                                .TrackLabel = lblTrackData0
                                .SectorLabel = lblSectorData0
                                .ReadLabel = lblReadData0
                                .WriteLabel = lblWriteData0
                            End With
                            If Disk0.Format() Then
                                ' Disk has been formatted
                                If Disk0.Open Then
                                    ' Disk is open
                                    lblFilename0.Text = Disk0.Filename
                                    lblSize0.Text = Disk0.SectorSize.ToString
                                Else
                                    ' Disk failed to open
                                    MsgBox("Disk failed to open.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                                    cboDisk0.Text = " "
                                End If
                            Else
                                ' Disk failed to format
                                MsgBox("Disk failed to format.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                                cboDisk0.Text = " "
                            End If
                            btnOpen0.Enabled = (cboDisk0.Text <> " " And Len(lblFilename0.Text) = 0)
                            btnNew0.Enabled = (cboDisk0.Text <> " " And Len(lblFilename0.Text) = 0)
                            btnBoot0.Enabled = (cboDisk0.Text = "A" And Len(lblFilename0.Text) > 0)
                        Case btnNew1.Name
                            Disk1 = New APEFileClass(NewFileDialog.FileName, CUShort(IIf(SectorSizeForm.ShowDialog() = Windows.Forms.DialogResult.Yes, 128, 512)))
                            lblTrackData1.Text = ""
                            lblSectorData1.Text = ""
                            lblReadData1.ForeColor = Color.Black
                            lblWriteData1.ForeColor = Color.Black
                            With Disk1
                                .TrackLabel = lblTrackData1
                                .SectorLabel = lblSectorData1
                                .ReadLabel = lblReadData1
                                .WriteLabel = lblWriteData1
                            End With
                            If Disk1.Format() Then
                                ' Disk has been formatted
                                If Disk1.Open Then
                                    ' Disk is open
                                    lblFilename1.Text = Disk1.Filename
                                    lblSize1.Text = Disk1.SectorSize.ToString
                                Else
                                    ' Disk failed to open
                                    MsgBox("Disk failed to open.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                                    cboDisk1.Text = " "
                                End If
                            Else
                                ' Disk failed to format
                                MsgBox("Disk failed to format.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                                cboDisk1.Text = " "
                            End If
                            btnOpen1.Enabled = (cboDisk1.Text <> " " And Len(lblFilename1.Text) = 0)
                            btnNew1.Enabled = (cboDisk1.Text <> " " And Len(lblFilename1.Text) = 0)
                            btnBoot1.Enabled = (cboDisk1.Text = "A" And Len(lblFilename1.Text) > 0)
                        Case btnNew2.Name
                            Disk2 = New APEFileClass(NewFileDialog.FileName, CUShort(IIf(SectorSizeForm.ShowDialog() = Windows.Forms.DialogResult.Yes, 128, 512)))
                            lblTrackData2.Text = ""
                            lblSectorData2.Text = ""
                            lblReadData2.ForeColor = Color.Black
                            lblWriteData2.ForeColor = Color.Black
                            With Disk2
                                .TrackLabel = lblTrackData2
                                .SectorLabel = lblSectorData2
                                .ReadLabel = lblReadData2
                                .WriteLabel = lblWriteData2
                            End With
                            If Disk2.Format() Then
                                ' Disk has been formatted
                                If Disk2.Open Then
                                    ' Disk is open
                                    lblFilename2.Text = Disk2.Filename
                                    lblSize2.Text = Disk2.SectorSize.ToString
                                Else
                                    ' Disk failed to open
                                    MsgBox("Disk failed to open.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                                    cboDisk2.Text = " "
                                End If
                            Else
                                ' Disk failed to format
                                MsgBox("Disk failed to format.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                                cboDisk2.Text = " "
                            End If
                            btnOpen2.Enabled = (cboDisk2.Text <> " " And Len(lblFilename2.Text) = 0)
                            btnNew2.Enabled = (cboDisk2.Text <> " " And Len(lblFilename2.Text) = 0)
                            btnBoot2.Enabled = (cboDisk2.Text = "A" And Len(lblFilename2.Text) > 0)
                        Case btnNew3.Name
                            Disk3 = New APEFileClass(NewFileDialog.FileName, CUShort(IIf(SectorSizeForm.ShowDialog() = Windows.Forms.DialogResult.Yes, 128, 512)))
                            lblTrackData3.Text = ""
                            lblSectorData3.Text = ""
                            lblReadData3.ForeColor = Color.Black
                            lblWriteData3.ForeColor = Color.Black
                            With Disk3
                                .TrackLabel = lblTrackData3
                                .SectorLabel = lblSectorData3
                                .ReadLabel = lblReadData3
                                .WriteLabel = lblWriteData3
                            End With
                            If Disk3.Format() Then
                                ' Disk has been formatted
                                If Disk3.Open Then
                                    ' Disk is open
                                    lblFilename3.Text = Disk3.Filename
                                    lblSize3.Text = Disk3.SectorSize.ToString
                                Else
                                    ' Disk failed to open
                                    MsgBox("Disk failed to open.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                                    cboDisk3.Text = " "
                                End If
                            Else
                                ' Disk failed to format
                                MsgBox("Disk failed to format.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                                cboDisk3.Text = " "
                            End If
                            btnOpen3.Enabled = (cboDisk3.Text <> " " And Len(lblFilename3.Text) = 0)
                            btnNew3.Enabled = (cboDisk3.Text <> " " And Len(lblFilename3.Text) = 0)
                            btnBoot3.Enabled = (cboDisk3.Text = "A" And Len(lblFilename3.Text) > 0)
                    End Select
                End If
        End Select
    End Sub

    Private Sub btnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpen0.Click, btnOpen1.Click, btnOpen2.Click, btnOpen3.Click
        Dim btnOpen As System.Windows.Forms.Button = CType(sender, System.Windows.Forms.Button)
        Select Case OpenFileDialog.ShowDialog(Me)
            Case Windows.Forms.DialogResult.Cancel
            Case Windows.Forms.DialogResult.OK
                Select Case btnOpen.Name
                    Case btnOpen0.Name
                        Disk0 = New APEFileClass(OpenFileDialog.FileName)
                        lblTrackData0.Text = ""
                        lblSectorData0.Text = ""
                        lblReadData0.ForeColor = Color.Black
                        lblWriteData0.ForeColor = Color.Black
                        With Disk0
                            .TrackLabel = lblTrackData0
                            .SectorLabel = lblSectorData0
                            .ReadLabel = lblReadData0
                            .WriteLabel = lblWriteData0
                        End With
                        If Disk0.Open Then
                            lblFilename0.Text = Disk0.Filename
                            lblSize0.Text = Disk0.SectorSize.ToString
                        Else
                            ' Disk failed to open
                            MsgBox("Disk failed to open.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                            cboDisk0.Text = " "
                        End If
                        btnOpen0.Enabled = (cboDisk0.Text <> " " And Len(lblFilename0.Text) = 0)
                        btnNew0.Enabled = (cboDisk0.Text <> " " And Len(lblFilename0.Text) = 0)
                        btnBoot0.Enabled = (cboDisk0.Text = "A" And Len(lblFilename0.Text) > 0)
                    Case btnOpen1.Name
                        Disk1 = New APEFileClass(OpenFileDialog.FileName)
                        lblTrackData1.Text = ""
                        lblSectorData1.Text = ""
                        lblReadData1.ForeColor = Color.Black
                        lblWriteData1.ForeColor = Color.Black
                        With Disk1
                            .TrackLabel = lblTrackData1
                            .SectorLabel = lblSectorData1
                            .ReadLabel = lblReadData1
                            .WriteLabel = lblWriteData1
                        End With
                        If Disk1.Open Then
                            lblFilename1.Text = Disk1.Filename
                            lblSize1.Text = Disk1.SectorSize.ToString
                        Else
                            ' Disk failed to open
                            MsgBox("Disk failed to open.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                            cboDisk1.Text = " "
                        End If
                        btnOpen1.Enabled = (cboDisk1.Text <> " " And Len(lblFilename1.Text) = 0)
                        btnNew1.Enabled = (cboDisk1.Text <> " " And Len(lblFilename1.Text) = 0)
                        btnBoot1.Enabled = (cboDisk1.Text = "A" And Len(lblFilename1.Text) > 0)
                    Case btnOpen2.Name
                        Disk2 = New APEFileClass(OpenFileDialog.FileName)
                        lblTrackData2.Text = ""
                        lblSectorData2.Text = ""
                        lblReadData2.ForeColor = Color.Black
                        lblWriteData2.ForeColor = Color.Black
                        With Disk2
                            .TrackLabel = lblTrackData2
                            .SectorLabel = lblSectorData2
                            .ReadLabel = lblReadData2
                            .WriteLabel = lblWriteData2
                        End With
                        If Disk2.Open Then
                            lblFilename2.Text = Disk2.Filename
                            lblSize2.Text = Disk2.SectorSize.ToString
                        Else
                            ' Disk failed to open
                            MsgBox("Disk failed to open.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                            cboDisk2.Text = " "
                        End If
                        btnOpen2.Enabled = (cboDisk2.Text <> " " And Len(lblFilename2.Text) = 0)
                        btnNew2.Enabled = (cboDisk2.Text <> " " And Len(lblFilename2.Text) = 0)
                        btnBoot2.Enabled = (cboDisk2.Text = "A" And Len(lblFilename2.Text) > 0)
                    Case btnOpen3.Name
                        Disk3 = New APEFileClass(OpenFileDialog.FileName)
                        lblTrackData3.Text = ""
                        lblSectorData3.Text = ""
                        lblReadData3.ForeColor = Color.Black
                        lblWriteData3.ForeColor = Color.Black
                        With Disk3
                            .TrackLabel = lblTrackData3
                            .SectorLabel = lblSectorData3
                            .ReadLabel = lblReadData3
                            .WriteLabel = lblWriteData3
                        End With
                        If Disk3.Open Then
                            lblFilename3.Text = Disk3.Filename
                            lblSize3.Text = Disk3.SectorSize.ToString
                        Else
                            ' Disk failed to open
                            MsgBox("Disk failed to open.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
                            cboDisk3.Text = " "
                        End If
                        btnOpen3.Enabled = (cboDisk3.Text <> " " And Len(lblFilename3.Text) = 0)
                        btnNew3.Enabled = (cboDisk3.Text <> " " And Len(lblFilename3.Text) = 0)
                        btnBoot3.Enabled = (cboDisk3.Text = "A" And Len(lblFilename3.Text) > 0)
                End Select
        End Select
    End Sub

    Private Sub btnBoot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBoot0.Click, btnBoot1.Click, btnBoot2.Click, btnBoot3.Click
        Const COLDBOOTSIZE As Integer = &H80

        Select Case MsgBox("Send Boot Sector?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question Or MsgBoxStyle.DefaultButton2, Me.Text)
            Case MsgBoxResult.No
                Exit Sub
            Case MsgBoxResult.Yes
        End Select

        ' Boot Sectors are always from disk "A" with 128 byte sectors
        If cboDisk0.Text = "A" Then
            If Disk0 IsNot Nothing Then SelectedDisk = Disk0
        ElseIf cboDisk1.Text = "A" Then
            If Disk1 IsNot Nothing Then SelectedDisk = Disk1
        ElseIf cboDisk2.Text = "A" Then
            If Disk2 IsNot Nothing Then SelectedDisk = Disk2
        ElseIf cboDisk3.Text = "A" Then
            If Disk3 IsNot Nothing Then SelectedDisk = Disk3
        End If
        If SelectedDisk IsNot Nothing Then

            SelectedDisk.Track = 0
            SelectedDisk.Sector = 1

            Debug.Print(String.Format("Serial Boot Track: {0}, Sector: {1}", SelectedDisk.Track, SelectedDisk.Sector))

            Dim SectorData(COLDBOOTSIZE - 1) As Byte
            If SelectedDisk.Read(SectorData) Then
                For Index As Integer = 0 To COLDBOOTSIZE - 1
                    SendCharacter(CInt(SectorData(Index))) ' Send Sector Data <byte>
                Next Index
            End If

            RXState = RXStates.Command

        End If
    End Sub

    Private Sub cboDisk0_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDisk0.GotFocus
        Dim cboDisk As System.Windows.Forms.ComboBox = CType(sender, System.Windows.Forms.ComboBox)
        With cboDisk
            If Len(.Text) = 0 Or .Text = " " Then
                .Items.Clear()
                .Items.Add(" ") ' None
                For Index As Integer = 0 To 15 ' A..P
                    Dim DiskLetter As String = Chr(Asc("A") + Index)
                    ' Add DiskLetter is not already in use...
                    If cboDisk1.Text <> DiskLetter And cboDisk2.Text <> DiskLetter And cboDisk3.Text <> DiskLetter Then
                        .Items.Add(DiskLetter)
                    End If
                Next Index
            End If
        End With
    End Sub

    Private Sub cboDisk0_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDisk0.SelectedValueChanged
        If cboDisk0.Text = " " Then
            If Disk0 IsNot Nothing Then Disk0.Close()
            Disk0 = Nothing
            lblTrackData0.Text = ""
            lblSectorData0.Text = ""
            lblReadData0.ForeColor = Color.Black
            lblWriteData0.ForeColor = Color.Black
            lblFilename0.Text = ""
            lblSize0.Text = ""
        End If
        btnOpen0.Enabled = (cboDisk0.Text <> " " And Len(lblFilename0.Text) = 0)
        btnNew0.Enabled = (cboDisk0.Text <> " " And Len(lblFilename0.Text) = 0)
        btnBoot0.Enabled = (cboDisk0.Text = "A" And Len(lblFilename0.Text) > 0)
    End Sub

    Private Sub cboDisk1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDisk1.GotFocus
        Dim cboDisk As System.Windows.Forms.ComboBox = CType(sender, System.Windows.Forms.ComboBox)
        With cboDisk
            If Len(.Text) = 0 Or .Text = " " Then
                .Items.Clear()
                .Items.Add(" ") ' None
                For Index As Integer = 0 To 15 ' A..P
                    Dim DiskLetter As String = Chr(Asc("A") + Index)
                    ' Add DiskLetter is not already in use...
                    If cboDisk0.Text <> DiskLetter And cboDisk2.Text <> DiskLetter And cboDisk3.Text <> DiskLetter Then
                        .Items.Add(DiskLetter)
                    End If
                Next Index
            End If
        End With
    End Sub

    Private Sub cboDisk1_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDisk1.SelectedValueChanged
        If cboDisk1.Text = " " Then
            If Disk1 IsNot Nothing Then Disk1.Close()
            Disk1 = Nothing
            lblTrackData1.Text = ""
            lblSectorData1.Text = ""
            lblReadData1.ForeColor = Color.Black
            lblWriteData1.ForeColor = Color.Black
            lblFilename1.Text = ""
            lblSize1.Text = ""
        End If
        btnOpen1.Enabled = (cboDisk1.Text <> " " And Len(lblFilename1.Text) = 0)
        btnNew1.Enabled = (cboDisk1.Text <> " " And Len(lblFilename1.Text) = 0)
        btnBoot1.Enabled = (cboDisk1.Text = "A" And Len(lblFilename1.Text) > 0)
    End Sub

    Private Sub cboDisk2_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDisk2.GotFocus
        Dim cboDisk As System.Windows.Forms.ComboBox = CType(sender, System.Windows.Forms.ComboBox)
        With cboDisk
            If Len(.Text) = 0 Or .Text = " " Then
                .Items.Clear()
                .Items.Add(" ") ' None
                For Index As Integer = 0 To 15 ' A..P
                    Dim DiskLetter As String = Chr(Asc("A") + Index)
                    ' Add DiskLetter is not already in use...
                    If cboDisk0.Text <> DiskLetter And cboDisk1.Text <> DiskLetter And cboDisk3.Text <> DiskLetter Then
                        .Items.Add(DiskLetter)
                    End If
                Next Index
            End If
        End With
    End Sub

    Private Sub cboDisk2_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDisk2.SelectedValueChanged
        If cboDisk2.Text = " " Then
            If Disk2 IsNot Nothing Then Disk2.Close()
            Disk2 = Nothing
            lblTrackData2.Text = ""
            lblSectorData2.Text = ""
            lblReadData2.ForeColor = Color.Black
            lblWriteData2.ForeColor = Color.Black
            lblFilename2.Text = ""
            lblSize2.Text = ""
        End If
        btnOpen2.Enabled = (cboDisk2.Text <> " " And Len(lblFilename2.Text) = 0)
        btnNew2.Enabled = (cboDisk2.Text <> " " And Len(lblFilename2.Text) = 0)
        btnBoot2.Enabled = (cboDisk2.Text = "A" And Len(lblFilename2.Text) > 0)
    End Sub

    Private Sub cboDisk3_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDisk3.GotFocus
        Dim cboDisk As System.Windows.Forms.ComboBox = CType(sender, System.Windows.Forms.ComboBox)
        With cboDisk
            If Len(.Text) = 0 Or .Text = " " Then
                .Items.Clear()
                .Items.Add(" ") ' None
                For Index As Integer = 0 To 15 ' A..P
                    Dim DiskLetter As String = Chr(Asc("A") + Index)
                    ' Add DiskLetter is not already in use...
                    If cboDisk0.Text <> DiskLetter And cboDisk1.Text <> DiskLetter And cboDisk2.Text <> DiskLetter Then
                        .Items.Add(DiskLetter)
                    End If
                Next Index
            End If
        End With
    End Sub

    Private Sub cboDisk3_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDisk3.SelectedValueChanged
        If cboDisk3.Text = " " Then
            If Disk3 IsNot Nothing Then Disk3.Close()
            Disk3 = Nothing
            lblTrackData3.Text = ""
            lblSectorData3.Text = ""
            lblReadData3.ForeColor = Color.Black
            lblWriteData3.ForeColor = Color.Black
            lblFilename3.Text = ""
            lblSize3.Text = ""
        End If
        btnOpen3.Enabled = (cboDisk3.Text <> " " And Len(lblFilename3.Text) = 0)
        btnNew3.Enabled = (cboDisk3.Text <> " " And Len(lblFilename3.Text) = 0)
        btnBoot3.Enabled = (cboDisk3.Text = "A" And Len(lblFilename3.Text) > 0)
    End Sub

#Region " Communications "
    Private SelectedDisk As APEFileClass = Nothing

    Private Enum RXStates
        Command = 0 ' Waiting for Command <byte>
        Data        ' Waiting for Data <byte>
        Checksum    ' Waiting for Command & Data Checksum <byte>
        WriteData   ' Waiting for Write Data <byte>[<byte>...]
    End Enum
    Private RXState As RXStates = RXStates.Command ' Current communication state

    Private RXCommand As Char           ' Received Command
    Private RXData As Integer           ' Received Data
    Private RXChecksum As UInt16 = 0    ' Received Checksum
    Private RXWriteData() As Byte       ' Received Write Data
    Private RXWriteCount As Integer     ' Number of Write Data bytes to receive
    Private RXWriteIndex As Integer     ' Index into RXWriteData() during receive

    Private Sub RXCharacter(ByVal ASCIICode As Integer)
        Select Case RXState
            Case RXStates.Command
                RXCommand = Chr(ASCIICode)      ' Save Command
                RXChecksum = CUShort(ASCIICode) ' Initialize receive Checksum
                RXState = RXStates.Data         ' Wait for Data...
            Case RXStates.Data
                RXData = ASCIICode              ' Save Data
                RXChecksum = CUShort(((RXChecksum + CUShort(ASCIICode)) And &HFF)) ' Update receive Checksum
                RXState = RXStates.Checksum     ' Wait for Command & Data Checksum...
            Case RXStates.Checksum
                RXChecksum = CUShort(((RXChecksum + CUShort(ASCIICode)) And &HFF)) ' Update receive Checksum
                ' Valid Command Frame?
                If RXChecksum <> 0 Then
                    SendCharacter(Asc("N"))     ' No - Send NAK to request resend of Command
                    RXState = RXStates.Command
                Else
                    ProcessRXCommand()          ' Yes - Send any Command response
                End If
            Case RXStates.WriteData
                If SelectedDisk IsNot Nothing Then
                    RXWriteData(RXWriteIndex) = CByte(ASCIICode) ' Save Write Data <byte>
                    RXChecksum = CUShort(((RXChecksum + CUShort(ASCIICode)) And &HFF)) ' Update receive Checksum
                    RXWriteIndex += 1           ' Advance Write Data Index...
                    RXWriteCount -= 1           ' ...and decrement Write Data Count
                    If RXWriteCount > 0 Then
                        RXState = RXStates.WriteData ' Wait for Write Data...
                    Else
                        ' Valid Write Data Frame?
                        If RXChecksum <> 0 Then
                            SendCharacter(Asc("N")) ' No - Send NAK to request resend of Write Command
                            RXState = RXStates.Command ' Wait for next Command...
                        Else
                            ReDim Preserve RXWriteData(SelectedDisk.SectorSize - 1) ' Yes - Remove Checksum <byte>...
                            If SelectedDisk.Write(RXWriteData) Then ' ...and write sector
                                SendCharacter(Asc("A")) ' Send ACK - Write Data received and written
                                RXState = RXStates.Command ' Wait for next Command...
                            Else
                                SendCharacter(Asc("N")) ' Send ERROR - Write Data received, but could not be written
                                RXState = RXStates.Command ' Wait for next Command...
                            End If
                        End If
                    End If
                End If
        End Select
    End Sub

    Private Sub ProcessRXCommand()
        Select Case RXCommand
            Case "B"c ' Boot Sector
                Debug.Print("Boot: " & RXData.ToString)
                ' Boot Sectors are always from disk "A" with 128 byte sectors
                If cboDisk0.Text = "A" Then
                    If Disk0 IsNot Nothing Then SelectedDisk = Disk0
                ElseIf cboDisk1.Text = "A" Then
                    If Disk1 IsNot Nothing Then SelectedDisk = Disk1
                ElseIf cboDisk2.Text = "A" Then
                    If Disk2 IsNot Nothing Then SelectedDisk = Disk2
                ElseIf cboDisk3.Text = "A" Then
                    If Disk3 IsNot Nothing Then SelectedDisk = Disk3
                End If
                If SelectedDisk IsNot Nothing Then

                    Dim NumberBootSectors As Integer ' Always as 128 byte sectors
                    Select Case SelectedDisk.SectorSize
                        Case 128 ' Track 0, Sectors 2..26 & Track 1, Sectors 1..26
                            NumberBootSectors = (SelectedDisk.SectorsPerTrack - 1) + SelectedDisk.SectorsPerTrack
                        Case 512 ' Track 0, Sectors 2..8 & Track 1, Sectors 1..8
                            NumberBootSectors = 4 * ((SelectedDisk.SectorsPerTrack - 1) + SelectedDisk.SectorsPerTrack)
                    End Select

                    Dim NextBootSector As Integer = RXData + 1
                    If NextBootSector >= NumberBootSectors Then
                        NextBootSector = 0
                    End If

                    ' Map Boot Sector in RXData (0..NumberBootSectors - 1)...
                    Select Case SelectedDisk.SectorSize
                        Case 128
                            If RXData < (SelectedDisk.SectorsPerTrack - 1) Then
                                SelectedDisk.Track = 0
                                SelectedDisk.Sector = RXData + 1 + 1 ' Boot starts with sector 2
                            Else
                                SelectedDisk.Track = 1
                                SelectedDisk.Sector = (RXData - (SelectedDisk.SectorsPerTrack - 1)) + 1
                            End If

                            Debug.Print(String.Format("Next Boot Sector: {0}, Track: {1}, Sector: {2}", NextBootSector, SelectedDisk.Track, SelectedDisk.Sector))

                            Dim SectorData(SelectedDisk.SectorSize - 1) As Byte
                            If SelectedDisk.Read(SectorData) Then
                                SendCharacter(Asc("A")) ' ACK - Command received
                                ' Send Command response...
                                Dim Checksum As UInt16 = 0 ' Initialize send checksum

                                SendCharacter(NextBootSector) ' Send Next Boot Sector <byte>
                                Checksum = CUShort(((Checksum + CUShort(NextBootSector)) And &HFF)) ' Update send Checksum

                                For Index As Integer = 0 To SelectedDisk.SectorSize - 1
                                    SendCharacter(CInt(SectorData(Index))) ' Send Sector Data <byte>
                                    Checksum = CUShort(((Checksum + CUShort(SectorData(Index))) And &HFF)) ' Update send Checksum
                                Next Index
                                SendCharacter((256 - Checksum) And &HFF) ' Send send Checksum
                                RXState = RXStates.Command ' Wait for Command response...
                            Else
                                SendCharacter(Asc("N")) ' Error processing Command
                                RXState = RXStates.Command
                            End If
                        Case 512
                            If RXData < 4 * (SelectedDisk.SectorsPerTrack - 1) Then
                                SelectedDisk.Track = 0
                                SelectedDisk.Sector = (RXData \ 4) + 1 + 1 ' Boot starts with sector 2
                            Else
                                SelectedDisk.Track = 1
                                SelectedDisk.Sector = ((RXData - (4 * (SelectedDisk.SectorsPerTrack - 1))) \ 4) + 1
                            End If
                            Dim Offset As Integer = (RXData Mod 4) * 128

                            Debug.Print(String.Format("Next Boot Sector: {0}, Track: {1}, Sector: {2}, Offset: {3}", NextBootSector, SelectedDisk.Track, SelectedDisk.Sector, Offset))

                            Dim SectorData(SelectedDisk.SectorSize - 1) As Byte
                            If SelectedDisk.Read(SectorData) Then
                                SendCharacter(Asc("A")) ' ACK - Command received
                                ' Send Command response...
                                Dim Checksum As UInt16 = 0 ' Initialize send checksum

                                SendCharacter(NextBootSector) ' Send Next Boot Sector <byte>
                                Checksum = CUShort(((Checksum + CUShort(NextBootSector)) And &HFF)) ' Update send Checksum

                                For Index As Integer = 0 + Offset To (128 - 1) + Offset
                                    SendCharacter(CInt(SectorData(Index))) ' Send Sector Data <byte>
                                    Checksum = CUShort(((Checksum + CUShort(SectorData(Index))) And &HFF)) ' Update send Checksum
                                Next Index
                                SendCharacter((256 - Checksum) And &HFF) ' Send send Checksum
                                RXState = RXStates.Command ' Wait for Command response...
                            Else
                                SendCharacter(Asc("N")) ' Error processing Command
                                RXState = RXStates.Command
                            End If
                    End Select
                Else
                    SendCharacter(Asc("N")) ' Error processing Command
                    RXState = RXStates.Command
                End If
            Case "D"c ' Set Disk from "Letter" (A..P) in RXData
                Debug.Print("Select Disk: " & Chr(RXData))
                SelectedDisk = nothing
                If cboDisk0.Text = Chr(RXData) Then
                    If Disk0 IsNot Nothing Then SelectedDisk = Disk0
                ElseIf cboDisk1.Text = Chr(RXData) Then
                    If Disk1 IsNot Nothing Then SelectedDisk = Disk1
                ElseIf cboDisk2.Text = Chr(RXData) Then
                    If Disk2 IsNot Nothing Then SelectedDisk = Disk2
                ElseIf cboDisk3.Text = Chr(RXData) Then
                    If Disk3 IsNot Nothing Then SelectedDisk = Disk3
                End If
                If SelectedDisk IsNot Nothing Then
                    SendCharacter(Asc("A")) ' Send ACK - Command received
                    RXState = RXStates.Command
                Else
                    SendCharacter(Asc("N")) ' Error processing Command
                    RXState = RXStates.Command
                End If
            Case "G"c ' Return Sector Length
                Debug.Print("Get Sector Length: " & RXData.ToString)
                If SelectedDisk IsNot Nothing Then
                    Select Case SelectedDisk.SectorSize
                        Case 128
                            SendCharacter(Asc("A")) ' Send ACK - Command received
                            ' Send Command response...
                            SendCharacter(0)    ' 0 = 128 bytes per sector
                            SendCharacter(0)    ' Checksum
                            RXState = RXStates.Command ' Wait for Command response...
                        Case 512
                            SendCharacter(Asc("A")) ' Send ACK - Command received
                            ' Send Command response...
                            SendCharacter(1)    ' 1 = 512 bytes per sector
                            SendCharacter(255)  ' Checksum
                            RXState = RXStates.Command ' Wait for Command response...
                    End Select
                Else
                    SendCharacter(Asc("N")) ' Error processing Command
                    RXState = RXStates.Command
                End If
            Case "T"c ' Set Track from RXData
                Debug.Print("Select Track: " & RXData.ToString)
                If SelectedDisk IsNot Nothing Then
                    SendCharacter(Asc("A")) ' ACK - Command processed
                    SelectedDisk.Track = RXData
                    RXState = RXStates.Command
                Else
                    SendCharacter(Asc("N")) ' Error processing Command
                    RXState = RXStates.Command
                End If
            Case "S"c ' Set Sector from RXData
                Debug.Print("Select Sector: " & RXData.ToString)
                If SelectedDisk IsNot Nothing Then
                    SendCharacter(Asc("A")) ' ACK - Command processed
                    SelectedDisk.Sector = RXData
                    RXState = RXStates.Command
                Else
                    SendCharacter(Asc("N")) ' Error processing Command
                    RXState = RXStates.Command
                End If
            Case "R"c ' Read Sector
                Debug.Print("Read: " & RXData.ToString)
                If SelectedDisk IsNot Nothing Then
                    Dim SectorData(SelectedDisk.SectorSize - 1) As Byte
                    If SelectedDisk.Read(SectorData) Then
                        SendCharacter(Asc("A")) ' ACK - Command received
                        ' Send Command response...
                        Dim Checksum As UInt16 = 0 ' Initialize send checksum
                        For Index As Integer = 0 To SelectedDisk.SectorSize - 1
                            SendCharacter(CInt(SectorData(Index))) ' Send Sector Data <byte>
                            Checksum = CUShort(((Checksum + CUShort(SectorData(Index))) And &HFF)) ' Update send Checksum
                        Next Index
                        SendCharacter((256 - Checksum) And &HFF) ' Send send Checksum
                        RXState = RXStates.Command ' Wait for Command response...
                    Else
                        SendCharacter(Asc("N")) ' Error processing Command
                        RXState = RXStates.Command
                    End If
                Else
                    SendCharacter(Asc("N")) ' Error processing Command
                    RXState = RXStates.Command
                End If
            Case "W"c ' Write Sector
                Debug.Print("Write: " & RXData.ToString)
                If SelectedDisk IsNot Nothing Then
                    SendCharacter(Asc("A"))     ' ACK - Command received
                    ' Size Write Data buffer to expected number of data bytes + 1 for Checksum
                    ReDim RXWriteData(SelectedDisk.SectorSize) ' (SelectedDisk.SectorSize - 1) <data>, (1) <Checksum>
                    RXWriteCount = SelectedDisk.SectorSize + 1 ' Expected number of data bytes + 1 for Checksum
                    RXWriteIndex = 0            ' Initalize Write Data Index...
                    RXChecksum = 0              ' ...and receive Checksum
                    RXState = RXStates.WriteData ' Wait for Write Data...
                Else
                    SendCharacter(Asc("N")) ' Error processing Command
                    RXState = RXStates.Command
                End If

                'Case "C"c ' Console Status
                'Case "I"c ' Console Input
                'Case "O"c ' Console Output
                'Case "L"c ' List Status
                'Case "P"c ' List Output

            Case Else
                Debug.Print("INVALID COMMAND: " & RXCommand.ToString & ", " & RXData.ToString)
                SendCharacter(Asc("N")) ' Error processing Command
                RXState = RXStates.Command ' Invalid commands are ignored...
        End Select
    End Sub
#End Region

#Region " Serial Port Setup "
    Private Sub SetupSerialPort(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCOMPort.SelectedValueChanged, cboBaudRate.SelectedValueChanged, cboParity.SelectedValueChanged, cboDataBits.SelectedValueChanged, cboStopBits.SelectedValueChanged, cboHandshaking.SelectedValueChanged
        If Len(cboCOMPort.Text) > 0 AndAlso Len(cboBaudRate.Text) > 0 AndAlso Len(cboParity.Text) > 0 AndAlso Len(cboDataBits.Text) > 0 AndAlso Len(cboStopBits.Text) > 0 AndAlso Len(cboHandshaking.Text) > 0 Then
            Try
                With Me.SerialPort1
                    If .IsOpen Then
                        .Close()
                    End If
                    .BaudRate = CInt(cboBaudRate.Text)
                    .DataBits = CInt(cboDataBits.Text)
                    Select Case cboStopBits.Text
                        Case "1"
                            .StopBits = IO.Ports.StopBits.One
                        Case "1.5"
                            .StopBits = IO.Ports.StopBits.OnePointFive
                        Case "2"
                            .StopBits = IO.Ports.StopBits.Two
                    End Select
                    .ParityReplace = CByte(Asc("?"))
                    Select Case cboParity.Text
                        Case "None"
                            .Parity = IO.Ports.Parity.None
                        Case "Even"
                            .Parity = IO.Ports.Parity.Even
                        Case "Odd"
                            .Parity = IO.Ports.Parity.Odd
                        Case "Mark"
                            .Parity = IO.Ports.Parity.Mark
                        Case "Space"
                            .Parity = IO.Ports.Parity.Space
                    End Select
                    .RtsEnable = True
                    .DtrEnable = True
                    Select Case cboHandshaking.Text
                        Case "None"
                            .Handshake = IO.Ports.Handshake.None
                        Case "RTS"
                            .Handshake = IO.Ports.Handshake.RequestToSend
                        Case "XOn/XOff"
                            .Handshake = IO.Ports.Handshake.XOnXOff
                        Case "RTS & XOn/XOff"
                            .Handshake = IO.Ports.Handshake.RequestToSendXOnXOff
                    End Select
                    .DiscardNull = False
                    .Encoding = System.Text.Encoding.UTF8
                    .PortName = cboCOMPort.Text
                    .Open()
                End With
            Catch ex As Exception
                MsgBox("Serial Port failed to open.  It may be in use by another program.", MsgBoxStyle.OkOnly Or MsgBoxStyle.Critical Or MsgBoxStyle.DefaultButton1, Me.Text)
            End Try
        End If
    End Sub
#End Region

#Region " Serial I/O "
    Private Sub SendCharacter(ByVal ASCIICode As Integer)
        With SerialPort1
            If .IsOpen Then
                Dim Buffer(1) As Byte
                Buffer(0) = CByte(ASCIICode)
                .Write(Buffer, 0, 1)
            End If
        End With
    End Sub

    Public Delegate Sub ReceiveCharacter(ByVal ASCIICode As Integer)

    Private Sub SerialPort1_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        With e
            Select Case .EventType
                Case IO.Ports.SerialData.Chars
                    Do While SerialPort1.BytesToRead > 0
                        Try
                            Me.Invoke(New ReceiveCharacter(AddressOf RXCharacter), SerialPort1.ReadByte())
                        Catch ex As Exception
                            ' Ignore for now
                        End Try
                    Loop
                Case IO.Ports.SerialData.Eof
            End Select
        End With
    End Sub

    Private Sub SerialPort1_ErrorReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialErrorReceivedEventArgs) Handles SerialPort1.ErrorReceived
        With e
            Select Case .EventType
                Case IO.Ports.SerialError.Frame
                Case IO.Ports.SerialError.Overrun
                Case IO.Ports.SerialError.RXOver
                Case IO.Ports.SerialError.RXParity
                Case IO.Ports.SerialError.TXFull
            End Select
        End With
    End Sub

    Private Sub SerialPort1_PinChanged(ByVal sender As Object, ByVal e As System.IO.Ports.SerialPinChangedEventArgs) Handles SerialPort1.PinChanged
        With e
            Select Case .EventType
                Case IO.Ports.SerialPinChange.Break
                Case IO.Ports.SerialPinChange.CDChanged
                Case IO.Ports.SerialPinChange.CtsChanged
                Case IO.Ports.SerialPinChange.DsrChanged
                Case IO.Ports.SerialPinChange.Ring
            End Select
        End With
    End Sub
#End Region

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblAPE.Click
        ' About information
        Dim MyCompany As String = ""
        Dim MyCopyright As String = ""
        Dim MyDescription As String = ""
        Dim MyProduct As String = ""
        Dim MyTitle As String = ""
        Dim MyTrademark As String = ""
        Dim MyVersion As String = System.Reflection.Assembly.GetExecutingAssembly.GetName.Version.ToString

        'Console.WriteLine()
        'Console.WriteLine()
        Dim MyAttributes() As Object = System.Reflection.Assembly.GetExecutingAssembly.GetCustomAttributes(False)
        For Each MyAttribute As Object In MyAttributes
            'Console.WriteLine(MyAttribute.GetType.Name)
            Select Case MyAttribute.GetType.Name
                Case "AssemblyCompanyAttribute"
                    Dim MyAssemblyCompany As System.Reflection.AssemblyCompanyAttribute = CType(MyAttribute, System.Reflection.AssemblyCompanyAttribute)
                    MyCompany = MyAssemblyCompany.Company
                Case "AssemblyCopyrightAttribute"
                    Dim MyAssemblyCopyright As System.Reflection.AssemblyCopyrightAttribute = CType(MyAttribute, System.Reflection.AssemblyCopyrightAttribute)
                    MyCopyright = MyAssemblyCopyright.Copyright
                Case "AssemblyDescriptionAttribute"
                    Dim MyAssemblyDescription As System.Reflection.AssemblyDescriptionAttribute = CType(MyAttribute, System.Reflection.AssemblyDescriptionAttribute)
                    MyDescription = MyAssemblyDescription.Description
                Case "AssemblyProductAttribute"
                    Dim MyAssemblyProduct As System.Reflection.AssemblyProductAttribute = CType(MyAttribute, System.Reflection.AssemblyProductAttribute)
                    MyProduct = MyAssemblyProduct.Product
                Case "AssemblyTitleAttribute"
                    Dim MyAssemblyTitle As System.Reflection.AssemblyTitleAttribute = CType(MyAttribute, System.Reflection.AssemblyTitleAttribute)
                    MyTitle = MyAssemblyTitle.Title
                Case "AssemblyTrademarkAttribute"
                    Dim MyAssemblyTrademark As System.Reflection.AssemblyTrademarkAttribute = CType(MyAttribute, System.Reflection.AssemblyTrademarkAttribute)
                    MyTrademark = MyAssemblyTrademark.Trademark
            End Select
        Next
        MsgBox(String.Format("About {0}", MyTitle) & vbCrLf & _
                vbCrLf & _
                String.Format("Version {0}", MyVersion) & vbCrLf & _
                MyProduct & vbCrLf & _
                MyCopyright & vbCrLf & _
                MyCompany & vbCrLf & _
                MyTrademark & vbCrLf & _
                MyDescription, _
            MsgBoxStyle.Information Or MsgBoxStyle.OkOnly, Me.Text)
    End Sub
End Class
