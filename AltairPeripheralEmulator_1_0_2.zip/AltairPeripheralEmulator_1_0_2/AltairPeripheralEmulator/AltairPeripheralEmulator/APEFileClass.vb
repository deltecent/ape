Public Class APEFileClass

    Private mFilename As String
    Private mSectorSize As UInt16
    Private mTracks As Integer
    Private mSectorsPerTrack As Integer

    Private mTrack As Integer
    Private mSector As Integer

    Private fs As System.IO.FileStream = Nothing
    Private bw As System.IO.BinaryWriter = Nothing
    Private br As System.IO.BinaryReader = Nothing

    Private mTrackLabel As System.Windows.Forms.Label
    Private mSectorLabel As System.Windows.Forms.Label
    Private mReadLabel As System.Windows.Forms.Label
    Private mReadOnColor As System.Drawing.Color
    Private mReadOffColor As System.Drawing.Color
    Private mWriteLabel As System.Windows.Forms.Label
    Private mWriteOnColor As System.Drawing.Color
    Private mWriteOffColor As System.Drawing.Color

    Public Sub New()
        mFilename = ""
        mSectorSize = 128
        mTracks = 77 ' 0..76
        Select Case mSectorSize
            Case 128
                mSectorsPerTrack = 26 ' 1..26
            Case 512
                mSectorsPerTrack = 8 ' 1..8
        End Select
        mTrack = 0
        mSector = 1

        mTrackLabel = Nothing
        mSectorLabel = Nothing
        mReadLabel = Nothing
        mReadOnColor = Color.LimeGreen
        mReadOffColor = Color.Black
        mWriteLabel = Nothing
        mWriteOnColor = Color.OrangeRed
        mWriteOffColor = Color.Black
    End Sub

    Public Sub New(ByVal Filename As String)
        mFilename = Filename
        mSectorSize = 128
        mTracks = 77
        Select Case mSectorSize
            Case 128
                mSectorsPerTrack = 26
            Case 512
                mSectorsPerTrack = 8
        End Select
        mTrack = 0
        mSector = 1

        mTrackLabel = Nothing
        mSectorLabel = Nothing
        mReadLabel = Nothing
        mReadOnColor = Color.LimeGreen
        mReadOffColor = Color.Black
        mWriteLabel = Nothing
        mWriteOnColor = Color.OrangeRed
        mWriteOffColor = Color.Black
    End Sub

    Public Sub New(ByVal Filename As String, ByVal SectorSize As UInt16)
        mFilename = Filename
        mSectorSize = SectorSize
        mTracks = 77
        Select Case mSectorSize
            Case 128
                mSectorsPerTrack = 26
            Case 512
                mSectorsPerTrack = 8
        End Select
        mTrack = 0
        mSector = 1

        mTrackLabel = Nothing
        mSectorLabel = Nothing
        mReadLabel = Nothing
        mReadOnColor = Color.LimeGreen
        mReadOffColor = Color.Black
        mWriteLabel = Nothing
        mWriteOnColor = Color.OrangeRed
        mWriteOffColor = Color.Black
    End Sub

    Public Property Filename() As String
        Get
            Filename = mFilename
        End Get
        Set(ByVal value As String)
            mFilename = value
        End Set
    End Property

    Public Property SectorSize() As UInt16
        Get
            SectorSize = mSectorSize
        End Get
        Set(ByVal value As UInt16)
            mSectorSize = value
            Select Case mSectorSize
                Case 128
                    mSectorsPerTrack = 26 ' 1..26
                Case 512
                    mSectorsPerTrack = 8 ' 1..8
            End Select
            mTrack = 0
            mSector = 1
        End Set
    End Property

    Public ReadOnly Property Tracks() As Integer
        Get
            Tracks = mTracks
        End Get
    End Property

    Public ReadOnly Property SectorsPerTrack() As Integer
        Get
            SectorsPerTrack = mSectorsPerTrack
        End Get
    End Property

    Public Property Track() As Integer ' 0..Tracks - 1
        Get
            Track = mTrack
        End Get
        Set(ByVal value As Integer)
            mTrack = value
            If mTrackLabel IsNot Nothing Then
                mTrackLabel.Text = mTrack.ToString
            End If
        End Set
    End Property

    Public Property Sector() As Integer ' 1..SectorsPerTrack
        Get
            Sector = mSector
        End Get
        Set(ByVal value As Integer)
            mSector = value
            If mSectorLabel IsNot Nothing Then
                mSectorLabel.Text = mSector.ToString
            End If
        End Set
    End Property

    Public Function Format() As Boolean
        Dim SectorData(SectorSize - 1) As Byte
        For Index As Integer = 0 To SectorSize - 1
            SectorData(Index) = 0
        Next
        If Len(Filename) > 0 Then
            Try
                Dim fs As System.IO.FileStream = New System.IO.FileStream(Filename, System.IO.FileMode.Create, System.IO.FileAccess.Write)
                Dim bw As System.IO.BinaryWriter = New System.IO.BinaryWriter(fs)
                Try
                    bw.Write(SectorSize) ' UInt16 - 2 bytes
                    For Track As Integer = 0 To Tracks - 1
                        For Sector As Integer = 1 To SectorsPerTrack
                            'fs.Seek(3 + Track * SectorsPerTrack * SectorSize + (Sector - 1) * SectorSize, IO.SeekOrigin.Begin)
                            bw.Write(SectorData)
                        Next Sector
                    Next Track
                    ' ERAse the directory areas...
                    Select Case SectorSize
                        Case 128
                            For Index As Long = &H1A03 To &H1B63 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H1C03 To &H1C63 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H1D03 To &H1E63 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H1F03 To &H1F63 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2003 To &H2163 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2203 To &H2263 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2303 To &H2363 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2403 To &H2463 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2503 To &H2563 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2603 To &H2663 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                        Case 512
                            For Index As Long = &H2003 To &H27E3 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                    End Select
                    Format = True ' Format complete
                Catch ex As Exception
                    Format = False ' Could not write file
                End Try
                bw.Close()
            Catch ex As Exception
                Format = False ' Could not create file
            End Try
        Else
            Format = False ' No Filename
        End If
    End Function

    Public Function Open() As Boolean
        If Len(Filename) > 0 Then
            Try
                fs = New System.IO.FileStream(Filename, System.IO.FileMode.Open, System.IO.FileAccess.ReadWrite)
                br = New System.IO.BinaryReader(fs)
                bw = New System.IO.BinaryWriter(fs)
                Try
                    SectorSize = br.ReadUInt16 ' UInt16 - 2 bytes
                    Open = True ' Open complete
                Catch ex As Exception
                    Open = False ' Could not read file
                End Try
                'br.Close()
            Catch ex As Exception
                Open = False ' Could not open file
            End Try
        Else
            Open = False ' No Filename
        End If
    End Function

    Public Sub Close()
        Try
            bw.Close()
            br.Close()
            fs.Close()
        Catch ex As Exception
            ' Ignored
        End Try
    End Sub

    Public Function Write(ByRef SectorData() As Byte) As Boolean
        If mWriteLabel IsNot Nothing Then
            mWriteLabel.ForeColor = mWriteOnColor
        End If
        If mReadLabel IsNot Nothing Then
            mReadLabel.ForeColor = mReadOffColor
        End If
        Try
            fs.Seek(3 + Track * SectorsPerTrack * SectorSize + (Sector - 1) * SectorSize, IO.SeekOrigin.Begin)
            bw.Write(SectorData)
            Write = True
        Catch ex As Exception
            Write = False
        End Try
    End Function

    Public Function Read(ByRef SectorData() As Byte) As Boolean
        If mReadLabel IsNot Nothing Then
            mReadLabel.ForeColor = mReadOnColor
        End If
        If mWriteLabel IsNot Nothing Then
            mWriteLabel.ForeColor = mWriteOffColor
        End If
        Try
            fs.Seek(3 + Track * SectorsPerTrack * SectorSize + (Sector - 1) * SectorSize, IO.SeekOrigin.Begin)
            SectorData = br.ReadBytes(SectorSize)
            Read = True
        Catch ex As Exception
            Read = False
        End Try
    End Function

    Public Property TrackLabel() As System.Windows.Forms.Label
        Get
            TrackLabel = mTrackLabel
        End Get
        Set(ByVal value As System.Windows.Forms.Label)
            mTrackLabel = value
        End Set
    End Property

    Public Property SectorLabel() As System.Windows.Forms.Label
        Get
            SectorLabel = mSectorLabel
        End Get
        Set(ByVal value As System.Windows.Forms.Label)
            mSectorLabel = value
        End Set
    End Property

    Public Property ReadLabel() As System.Windows.Forms.Label
        Get
            ReadLabel = mReadLabel
        End Get
        Set(ByVal value As System.Windows.Forms.Label)
            mReadLabel = value
        End Set
    End Property

    Public Property WriteLabel() As System.Windows.Forms.Label
        Get
            WriteLabel = mWriteLabel
        End Get
        Set(ByVal value As System.Windows.Forms.Label)
            mWriteLabel = value
        End Set
    End Property

End Class
