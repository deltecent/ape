Public Class SectorSizeForm

    Private Sub btn128_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn128.Click
        Me.DialogResult = Windows.Forms.DialogResult.Yes
        Me.Close()
    End Sub

    Private Sub btn512_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn512.Click
        Me.DialogResult = Windows.Forms.DialogResult.No
        Me.Close()
    End Sub

    Private Sub SectorSizeForm_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        btn128.Focus()
    End Sub
End Class