<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.cboDisk1 = New System.Windows.Forms.ComboBox
        Me.cboDisk2 = New System.Windows.Forms.ComboBox
        Me.cboDisk3 = New System.Windows.Forms.ComboBox
        Me.lblFilename1 = New System.Windows.Forms.Label
        Me.lblFilename2 = New System.Windows.Forms.Label
        Me.lblFilename3 = New System.Windows.Forms.Label
        Me.btnOpen0 = New System.Windows.Forms.Button
        Me.btnOpen1 = New System.Windows.Forms.Button
        Me.btnOpen2 = New System.Windows.Forms.Button
        Me.btnOpen3 = New System.Windows.Forms.Button
        Me.btnNew0 = New System.Windows.Forms.Button
        Me.btnNew1 = New System.Windows.Forms.Button
        Me.btnNew2 = New System.Windows.Forms.Button
        Me.btnNew3 = New System.Windows.Forms.Button
        Me.lblSize3 = New System.Windows.Forms.Label
        Me.lblSize2 = New System.Windows.Forms.Label
        Me.lblSize1 = New System.Windows.Forms.Label
        Me.NewFileDialog = New System.Windows.Forms.OpenFileDialog
        Me.btnBoot0 = New System.Windows.Forms.Button
        Me.btnBoot1 = New System.Windows.Forms.Button
        Me.btnBoot2 = New System.Windows.Forms.Button
        Me.btnBoot3 = New System.Windows.Forms.Button
        Me.cboCOMPort = New System.Windows.Forms.ComboBox
        Me.cboBaudRate = New System.Windows.Forms.ComboBox
        Me.cboParity = New System.Windows.Forms.ComboBox
        Me.cboDataBits = New System.Windows.Forms.ComboBox
        Me.cboStopBits = New System.Windows.Forms.ComboBox
        Me.cboHandshaking = New System.Windows.Forms.ComboBox
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.lblSectorSize1 = New System.Windows.Forms.Label
        Me.lblSectorSize2 = New System.Windows.Forms.Label
        Me.lblSectorSize3 = New System.Windows.Forms.Label
        Me.lblWriteData1 = New System.Windows.Forms.Label
        Me.lblWrite1 = New System.Windows.Forms.Label
        Me.lblWriteData2 = New System.Windows.Forms.Label
        Me.lblWrite2 = New System.Windows.Forms.Label
        Me.lblWriteData3 = New System.Windows.Forms.Label
        Me.lblWrite3 = New System.Windows.Forms.Label
        Me.lblReadData1 = New System.Windows.Forms.Label
        Me.lblRead1 = New System.Windows.Forms.Label
        Me.lblReadData2 = New System.Windows.Forms.Label
        Me.lblRead2 = New System.Windows.Forms.Label
        Me.lblReadData3 = New System.Windows.Forms.Label
        Me.lblRead3 = New System.Windows.Forms.Label
        Me.lblSectorData1 = New System.Windows.Forms.Label
        Me.lblSector1 = New System.Windows.Forms.Label
        Me.lblSectorData2 = New System.Windows.Forms.Label
        Me.lblSector2 = New System.Windows.Forms.Label
        Me.lblSectorData3 = New System.Windows.Forms.Label
        Me.lblSector3 = New System.Windows.Forms.Label
        Me.lblTrackData1 = New System.Windows.Forms.Label
        Me.lblTrack1 = New System.Windows.Forms.Label
        Me.lblTrackData2 = New System.Windows.Forms.Label
        Me.lblTrack2 = New System.Windows.Forms.Label
        Me.lblTrackData3 = New System.Windows.Forms.Label
        Me.lblTrack3 = New System.Windows.Forms.Label
        Me.lblSectorSize0 = New System.Windows.Forms.Label
        Me.lblSector0 = New System.Windows.Forms.Label
        Me.lblTrack0 = New System.Windows.Forms.Label
        Me.cboDisk0 = New System.Windows.Forms.ComboBox
        Me.lblFilename0 = New System.Windows.Forms.Label
        Me.lblSize0 = New System.Windows.Forms.Label
        Me.lblTrackData0 = New System.Windows.Forms.Label
        Me.lblSectorData0 = New System.Windows.Forms.Label
        Me.lblRead0 = New System.Windows.Forms.Label
        Me.lblReadData0 = New System.Windows.Forms.Label
        Me.lblWrite0 = New System.Windows.Forms.Label
        Me.lblWriteData0 = New System.Windows.Forms.Label
        Me.lblAPE = New System.Windows.Forms.Label
        Me.lblDiskTypeData0 = New System.Windows.Forms.Label
        Me.lblDiskTypeData1 = New System.Windows.Forms.Label
        Me.lblDiskTypeData2 = New System.Windows.Forms.Label
        Me.lblDiskTypeData3 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'cboDisk1
        '
        Me.cboDisk1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cboDisk1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDisk1.FormattingEnabled = True
        Me.cboDisk1.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P"})
        Me.cboDisk1.Location = New System.Drawing.Point(11, 115)
        Me.cboDisk1.Name = "cboDisk1"
        Me.cboDisk1.Size = New System.Drawing.Size(39, 21)
        Me.cboDisk1.TabIndex = 6
        '
        'cboDisk2
        '
        Me.cboDisk2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cboDisk2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDisk2.FormattingEnabled = True
        Me.cboDisk2.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P"})
        Me.cboDisk2.Location = New System.Drawing.Point(11, 179)
        Me.cboDisk2.Name = "cboDisk2"
        Me.cboDisk2.Size = New System.Drawing.Size(39, 21)
        Me.cboDisk2.TabIndex = 12
        '
        'cboDisk3
        '
        Me.cboDisk3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cboDisk3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDisk3.FormattingEnabled = True
        Me.cboDisk3.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P"})
        Me.cboDisk3.Location = New System.Drawing.Point(11, 243)
        Me.cboDisk3.Name = "cboDisk3"
        Me.cboDisk3.Size = New System.Drawing.Size(39, 21)
        Me.cboDisk3.TabIndex = 18
        '
        'lblFilename1
        '
        Me.lblFilename1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblFilename1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilename1.ForeColor = System.Drawing.Color.Black
        Me.lblFilename1.Location = New System.Drawing.Point(56, 115)
        Me.lblFilename1.Name = "lblFilename1"
        Me.lblFilename1.Size = New System.Drawing.Size(515, 21)
        Me.lblFilename1.TabIndex = 7
        Me.lblFilename1.Text = "lblFilename1"
        Me.lblFilename1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFilename2
        '
        Me.lblFilename2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblFilename2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilename2.ForeColor = System.Drawing.Color.Black
        Me.lblFilename2.Location = New System.Drawing.Point(56, 179)
        Me.lblFilename2.Name = "lblFilename2"
        Me.lblFilename2.Size = New System.Drawing.Size(515, 21)
        Me.lblFilename2.TabIndex = 13
        Me.lblFilename2.Text = "lblFilename2"
        Me.lblFilename2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFilename3
        '
        Me.lblFilename3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblFilename3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilename3.ForeColor = System.Drawing.Color.Black
        Me.lblFilename3.Location = New System.Drawing.Point(56, 243)
        Me.lblFilename3.Name = "lblFilename3"
        Me.lblFilename3.Size = New System.Drawing.Size(516, 21)
        Me.lblFilename3.TabIndex = 19
        Me.lblFilename3.Text = "lblFilename3"
        Me.lblFilename3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnOpen0
        '
        Me.btnOpen0.Enabled = False
        Me.btnOpen0.Location = New System.Drawing.Point(394, 76)
        Me.btnOpen0.Name = "btnOpen0"
        Me.btnOpen0.Size = New System.Drawing.Size(55, 23)
        Me.btnOpen0.TabIndex = 3
        Me.btnOpen0.Text = "&Open..."
        Me.btnOpen0.UseVisualStyleBackColor = True
        '
        'btnOpen1
        '
        Me.btnOpen1.Enabled = False
        Me.btnOpen1.Location = New System.Drawing.Point(394, 140)
        Me.btnOpen1.Name = "btnOpen1"
        Me.btnOpen1.Size = New System.Drawing.Size(55, 23)
        Me.btnOpen1.TabIndex = 9
        Me.btnOpen1.Text = "&Open..."
        Me.btnOpen1.UseVisualStyleBackColor = True
        '
        'btnOpen2
        '
        Me.btnOpen2.Enabled = False
        Me.btnOpen2.Location = New System.Drawing.Point(394, 204)
        Me.btnOpen2.Name = "btnOpen2"
        Me.btnOpen2.Size = New System.Drawing.Size(55, 23)
        Me.btnOpen2.TabIndex = 15
        Me.btnOpen2.Text = "&Open..."
        Me.btnOpen2.UseVisualStyleBackColor = True
        '
        'btnOpen3
        '
        Me.btnOpen3.Enabled = False
        Me.btnOpen3.Location = New System.Drawing.Point(394, 268)
        Me.btnOpen3.Name = "btnOpen3"
        Me.btnOpen3.Size = New System.Drawing.Size(55, 23)
        Me.btnOpen3.TabIndex = 21
        Me.btnOpen3.Text = "&Open..."
        Me.btnOpen3.UseVisualStyleBackColor = True
        '
        'btnNew0
        '
        Me.btnNew0.Enabled = False
        Me.btnNew0.Location = New System.Drawing.Point(455, 76)
        Me.btnNew0.Name = "btnNew0"
        Me.btnNew0.Size = New System.Drawing.Size(55, 23)
        Me.btnNew0.TabIndex = 4
        Me.btnNew0.Text = "&New..."
        Me.btnNew0.UseVisualStyleBackColor = True
        '
        'btnNew1
        '
        Me.btnNew1.Enabled = False
        Me.btnNew1.Location = New System.Drawing.Point(455, 140)
        Me.btnNew1.Name = "btnNew1"
        Me.btnNew1.Size = New System.Drawing.Size(55, 23)
        Me.btnNew1.TabIndex = 10
        Me.btnNew1.Text = "&New..."
        Me.btnNew1.UseVisualStyleBackColor = True
        '
        'btnNew2
        '
        Me.btnNew2.Enabled = False
        Me.btnNew2.Location = New System.Drawing.Point(455, 204)
        Me.btnNew2.Name = "btnNew2"
        Me.btnNew2.Size = New System.Drawing.Size(55, 23)
        Me.btnNew2.TabIndex = 16
        Me.btnNew2.Text = "&New..."
        Me.btnNew2.UseVisualStyleBackColor = True
        '
        'btnNew3
        '
        Me.btnNew3.Enabled = False
        Me.btnNew3.Location = New System.Drawing.Point(455, 268)
        Me.btnNew3.Name = "btnNew3"
        Me.btnNew3.Size = New System.Drawing.Size(55, 23)
        Me.btnNew3.TabIndex = 22
        Me.btnNew3.Text = "&New..."
        Me.btnNew3.UseVisualStyleBackColor = True
        '
        'lblSize3
        '
        Me.lblSize3.BackColor = System.Drawing.Color.Black
        Me.lblSize3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSize3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSize3.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblSize3.Location = New System.Drawing.Point(352, 270)
        Me.lblSize3.Name = "lblSize3"
        Me.lblSize3.Size = New System.Drawing.Size(27, 19)
        Me.lblSize3.TabIndex = 20
        Me.lblSize3.Text = "888"
        Me.lblSize3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSize2
        '
        Me.lblSize2.BackColor = System.Drawing.Color.Black
        Me.lblSize2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSize2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSize2.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblSize2.Location = New System.Drawing.Point(352, 206)
        Me.lblSize2.Name = "lblSize2"
        Me.lblSize2.Size = New System.Drawing.Size(27, 19)
        Me.lblSize2.TabIndex = 14
        Me.lblSize2.Text = "888"
        Me.lblSize2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSize1
        '
        Me.lblSize1.BackColor = System.Drawing.Color.Black
        Me.lblSize1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSize1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSize1.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblSize1.Location = New System.Drawing.Point(352, 142)
        Me.lblSize1.Name = "lblSize1"
        Me.lblSize1.Size = New System.Drawing.Size(27, 19)
        Me.lblSize1.TabIndex = 8
        Me.lblSize1.Text = "888"
        Me.lblSize1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NewFileDialog
        '
        Me.NewFileDialog.CheckFileExists = False
        Me.NewFileDialog.DefaultExt = "APE"
        Me.NewFileDialog.FileName = "Untitled"
        Me.NewFileDialog.Filter = "Altair files (*.ape)|*.ape|All files (*.*)|*.*"
        Me.NewFileDialog.Title = "New Altair Disk File"
        '
        'btnBoot0
        '
        Me.btnBoot0.Enabled = False
        Me.btnBoot0.Location = New System.Drawing.Point(516, 76)
        Me.btnBoot0.Name = "btnBoot0"
        Me.btnBoot0.Size = New System.Drawing.Size(55, 23)
        Me.btnBoot0.TabIndex = 5
        Me.btnBoot0.Text = "&Boot"
        Me.btnBoot0.UseVisualStyleBackColor = True
        '
        'btnBoot1
        '
        Me.btnBoot1.Enabled = False
        Me.btnBoot1.Location = New System.Drawing.Point(516, 140)
        Me.btnBoot1.Name = "btnBoot1"
        Me.btnBoot1.Size = New System.Drawing.Size(55, 23)
        Me.btnBoot1.TabIndex = 11
        Me.btnBoot1.Text = "&Boot"
        Me.btnBoot1.UseVisualStyleBackColor = True
        '
        'btnBoot2
        '
        Me.btnBoot2.Enabled = False
        Me.btnBoot2.Location = New System.Drawing.Point(516, 204)
        Me.btnBoot2.Name = "btnBoot2"
        Me.btnBoot2.Size = New System.Drawing.Size(55, 23)
        Me.btnBoot2.TabIndex = 17
        Me.btnBoot2.Text = "&Boot"
        Me.btnBoot2.UseVisualStyleBackColor = True
        '
        'btnBoot3
        '
        Me.btnBoot3.Enabled = False
        Me.btnBoot3.Location = New System.Drawing.Point(516, 268)
        Me.btnBoot3.Name = "btnBoot3"
        Me.btnBoot3.Size = New System.Drawing.Size(55, 23)
        Me.btnBoot3.TabIndex = 23
        Me.btnBoot3.Text = "&Boot"
        Me.btnBoot3.UseVisualStyleBackColor = True
        '
        'cboCOMPort
        '
        Me.cboCOMPort.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cboCOMPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCOMPort.FormattingEnabled = True
        Me.cboCOMPort.Location = New System.Drawing.Point(11, 12)
        Me.cboCOMPort.Name = "cboCOMPort"
        Me.cboCOMPort.Size = New System.Drawing.Size(63, 21)
        Me.cboCOMPort.Sorted = True
        Me.cboCOMPort.TabIndex = 24
        '
        'cboBaudRate
        '
        Me.cboBaudRate.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cboBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBaudRate.FormattingEnabled = True
        Me.cboBaudRate.Items.AddRange(New Object() {"19200", "9600", "4800", "2400", "1200", "300", "110"})
        Me.cboBaudRate.Location = New System.Drawing.Point(80, 12)
        Me.cboBaudRate.Name = "cboBaudRate"
        Me.cboBaudRate.Size = New System.Drawing.Size(63, 21)
        Me.cboBaudRate.TabIndex = 25
        '
        'cboParity
        '
        Me.cboParity.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cboParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboParity.FormattingEnabled = True
        Me.cboParity.Items.AddRange(New Object() {"None", "Even", "Odd", "Mark", "Space"})
        Me.cboParity.Location = New System.Drawing.Point(149, 12)
        Me.cboParity.Name = "cboParity"
        Me.cboParity.Size = New System.Drawing.Size(63, 21)
        Me.cboParity.TabIndex = 26
        '
        'cboDataBits
        '
        Me.cboDataBits.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cboDataBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDataBits.FormattingEnabled = True
        Me.cboDataBits.Items.AddRange(New Object() {"8", "7"})
        Me.cboDataBits.Location = New System.Drawing.Point(218, 12)
        Me.cboDataBits.Name = "cboDataBits"
        Me.cboDataBits.Size = New System.Drawing.Size(63, 21)
        Me.cboDataBits.TabIndex = 27
        '
        'cboStopBits
        '
        Me.cboStopBits.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cboStopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStopBits.FormattingEnabled = True
        Me.cboStopBits.Items.AddRange(New Object() {"1", "1.5", "2"})
        Me.cboStopBits.Location = New System.Drawing.Point(287, 12)
        Me.cboStopBits.Name = "cboStopBits"
        Me.cboStopBits.Size = New System.Drawing.Size(63, 21)
        Me.cboStopBits.TabIndex = 28
        '
        'cboHandshaking
        '
        Me.cboHandshaking.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cboHandshaking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboHandshaking.FormattingEnabled = True
        Me.cboHandshaking.Items.AddRange(New Object() {"None", "RTS", "XOn/XOff", "RTS & XOn/XOff"})
        Me.cboHandshaking.Location = New System.Drawing.Point(356, 12)
        Me.cboHandshaking.Name = "cboHandshaking"
        Me.cboHandshaking.Size = New System.Drawing.Size(107, 21)
        Me.cboHandshaking.TabIndex = 29
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.DefaultExt = "APE"
        Me.OpenFileDialog.FileName = "Untitled"
        Me.OpenFileDialog.Filter = "Altair files (*.ape)|*.ape|All files (*.*)|*.*"
        Me.OpenFileDialog.Title = "Open Altair Disk File"
        '
        'SerialPort1
        '
        '
        'lblSectorSize1
        '
        Me.lblSectorSize1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblSectorSize1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSectorSize1.ForeColor = System.Drawing.Color.Black
        Me.lblSectorSize1.Location = New System.Drawing.Point(309, 141)
        Me.lblSectorSize1.Name = "lblSectorSize1"
        Me.lblSectorSize1.Size = New System.Drawing.Size(70, 21)
        Me.lblSectorSize1.TabIndex = 39
        Me.lblSectorSize1.Text = "Size"
        Me.lblSectorSize1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSectorSize2
        '
        Me.lblSectorSize2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblSectorSize2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSectorSize2.ForeColor = System.Drawing.Color.Black
        Me.lblSectorSize2.Location = New System.Drawing.Point(309, 205)
        Me.lblSectorSize2.Name = "lblSectorSize2"
        Me.lblSectorSize2.Size = New System.Drawing.Size(70, 21)
        Me.lblSectorSize2.TabIndex = 40
        Me.lblSectorSize2.Text = "Size"
        Me.lblSectorSize2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSectorSize3
        '
        Me.lblSectorSize3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblSectorSize3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSectorSize3.ForeColor = System.Drawing.Color.Black
        Me.lblSectorSize3.Location = New System.Drawing.Point(309, 269)
        Me.lblSectorSize3.Name = "lblSectorSize3"
        Me.lblSectorSize3.Size = New System.Drawing.Size(70, 21)
        Me.lblSectorSize3.TabIndex = 41
        Me.lblSectorSize3.Text = "Size"
        Me.lblSectorSize3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWriteData1
        '
        Me.lblWriteData1.BackColor = System.Drawing.Color.Black
        Me.lblWriteData1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWriteData1.ForeColor = System.Drawing.Color.OrangeRed
        Me.lblWriteData1.Location = New System.Drawing.Point(291, 142)
        Me.lblWriteData1.Name = "lblWriteData1"
        Me.lblWriteData1.Size = New System.Drawing.Size(12, 19)
        Me.lblWriteData1.TabIndex = 43
        Me.lblWriteData1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblWrite1
        '
        Me.lblWrite1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblWrite1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblWrite1.ForeColor = System.Drawing.Color.Black
        Me.lblWrite1.Location = New System.Drawing.Point(258, 141)
        Me.lblWrite1.Name = "lblWrite1"
        Me.lblWrite1.Size = New System.Drawing.Size(45, 21)
        Me.lblWrite1.TabIndex = 42
        Me.lblWrite1.Text = "Write"
        Me.lblWrite1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWriteData2
        '
        Me.lblWriteData2.BackColor = System.Drawing.Color.Black
        Me.lblWriteData2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWriteData2.ForeColor = System.Drawing.Color.OrangeRed
        Me.lblWriteData2.Location = New System.Drawing.Point(291, 206)
        Me.lblWriteData2.Name = "lblWriteData2"
        Me.lblWriteData2.Size = New System.Drawing.Size(12, 19)
        Me.lblWriteData2.TabIndex = 45
        Me.lblWriteData2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblWrite2
        '
        Me.lblWrite2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblWrite2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblWrite2.ForeColor = System.Drawing.Color.Black
        Me.lblWrite2.Location = New System.Drawing.Point(258, 205)
        Me.lblWrite2.Name = "lblWrite2"
        Me.lblWrite2.Size = New System.Drawing.Size(45, 21)
        Me.lblWrite2.TabIndex = 44
        Me.lblWrite2.Text = "Write"
        Me.lblWrite2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWriteData3
        '
        Me.lblWriteData3.BackColor = System.Drawing.Color.Black
        Me.lblWriteData3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWriteData3.ForeColor = System.Drawing.Color.OrangeRed
        Me.lblWriteData3.Location = New System.Drawing.Point(291, 270)
        Me.lblWriteData3.Name = "lblWriteData3"
        Me.lblWriteData3.Size = New System.Drawing.Size(12, 19)
        Me.lblWriteData3.TabIndex = 47
        Me.lblWriteData3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblWrite3
        '
        Me.lblWrite3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblWrite3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblWrite3.ForeColor = System.Drawing.Color.Black
        Me.lblWrite3.Location = New System.Drawing.Point(258, 269)
        Me.lblWrite3.Name = "lblWrite3"
        Me.lblWrite3.Size = New System.Drawing.Size(45, 21)
        Me.lblWrite3.TabIndex = 46
        Me.lblWrite3.Text = "Write"
        Me.lblWrite3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblReadData1
        '
        Me.lblReadData1.BackColor = System.Drawing.Color.Black
        Me.lblReadData1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReadData1.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblReadData1.Location = New System.Drawing.Point(240, 142)
        Me.lblReadData1.Name = "lblReadData1"
        Me.lblReadData1.Size = New System.Drawing.Size(12, 19)
        Me.lblReadData1.TabIndex = 49
        Me.lblReadData1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRead1
        '
        Me.lblRead1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblRead1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRead1.ForeColor = System.Drawing.Color.Black
        Me.lblRead1.Location = New System.Drawing.Point(207, 141)
        Me.lblRead1.Name = "lblRead1"
        Me.lblRead1.Size = New System.Drawing.Size(45, 21)
        Me.lblRead1.TabIndex = 48
        Me.lblRead1.Text = "Read"
        Me.lblRead1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblReadData2
        '
        Me.lblReadData2.BackColor = System.Drawing.Color.Black
        Me.lblReadData2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReadData2.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblReadData2.Location = New System.Drawing.Point(240, 206)
        Me.lblReadData2.Name = "lblReadData2"
        Me.lblReadData2.Size = New System.Drawing.Size(12, 19)
        Me.lblReadData2.TabIndex = 51
        Me.lblReadData2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRead2
        '
        Me.lblRead2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblRead2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRead2.ForeColor = System.Drawing.Color.Black
        Me.lblRead2.Location = New System.Drawing.Point(207, 205)
        Me.lblRead2.Name = "lblRead2"
        Me.lblRead2.Size = New System.Drawing.Size(45, 21)
        Me.lblRead2.TabIndex = 50
        Me.lblRead2.Text = "Read"
        Me.lblRead2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblReadData3
        '
        Me.lblReadData3.BackColor = System.Drawing.Color.Black
        Me.lblReadData3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReadData3.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblReadData3.Location = New System.Drawing.Point(240, 270)
        Me.lblReadData3.Name = "lblReadData3"
        Me.lblReadData3.Size = New System.Drawing.Size(12, 19)
        Me.lblReadData3.TabIndex = 53
        Me.lblReadData3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRead3
        '
        Me.lblRead3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblRead3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRead3.ForeColor = System.Drawing.Color.Black
        Me.lblRead3.Location = New System.Drawing.Point(207, 269)
        Me.lblRead3.Name = "lblRead3"
        Me.lblRead3.Size = New System.Drawing.Size(45, 21)
        Me.lblRead3.TabIndex = 52
        Me.lblRead3.Text = "Read"
        Me.lblRead3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSectorData1
        '
        Me.lblSectorData1.BackColor = System.Drawing.Color.Black
        Me.lblSectorData1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSectorData1.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblSectorData1.Location = New System.Drawing.Point(174, 142)
        Me.lblSectorData1.Name = "lblSectorData1"
        Me.lblSectorData1.Size = New System.Drawing.Size(27, 19)
        Me.lblSectorData1.TabIndex = 55
        Me.lblSectorData1.Text = "888"
        Me.lblSectorData1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSector1
        '
        Me.lblSector1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblSector1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSector1.ForeColor = System.Drawing.Color.Black
        Me.lblSector1.Location = New System.Drawing.Point(132, 141)
        Me.lblSector1.Name = "lblSector1"
        Me.lblSector1.Size = New System.Drawing.Size(70, 21)
        Me.lblSector1.TabIndex = 54
        Me.lblSector1.Text = "Sector"
        Me.lblSector1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSectorData2
        '
        Me.lblSectorData2.BackColor = System.Drawing.Color.Black
        Me.lblSectorData2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSectorData2.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblSectorData2.Location = New System.Drawing.Point(174, 206)
        Me.lblSectorData2.Name = "lblSectorData2"
        Me.lblSectorData2.Size = New System.Drawing.Size(27, 19)
        Me.lblSectorData2.TabIndex = 57
        Me.lblSectorData2.Text = "888"
        Me.lblSectorData2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSector2
        '
        Me.lblSector2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblSector2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSector2.ForeColor = System.Drawing.Color.Black
        Me.lblSector2.Location = New System.Drawing.Point(132, 205)
        Me.lblSector2.Name = "lblSector2"
        Me.lblSector2.Size = New System.Drawing.Size(70, 21)
        Me.lblSector2.TabIndex = 56
        Me.lblSector2.Text = "Sector"
        Me.lblSector2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSectorData3
        '
        Me.lblSectorData3.BackColor = System.Drawing.Color.Black
        Me.lblSectorData3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSectorData3.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblSectorData3.Location = New System.Drawing.Point(174, 270)
        Me.lblSectorData3.Name = "lblSectorData3"
        Me.lblSectorData3.Size = New System.Drawing.Size(27, 19)
        Me.lblSectorData3.TabIndex = 59
        Me.lblSectorData3.Text = "888"
        Me.lblSectorData3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSector3
        '
        Me.lblSector3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblSector3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSector3.ForeColor = System.Drawing.Color.Black
        Me.lblSector3.Location = New System.Drawing.Point(131, 269)
        Me.lblSector3.Name = "lblSector3"
        Me.lblSector3.Size = New System.Drawing.Size(70, 21)
        Me.lblSector3.TabIndex = 58
        Me.lblSector3.Text = "Sector"
        Me.lblSector3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTrackData1
        '
        Me.lblTrackData1.BackColor = System.Drawing.Color.Black
        Me.lblTrackData1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTrackData1.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblTrackData1.Location = New System.Drawing.Point(98, 142)
        Me.lblTrackData1.Name = "lblTrackData1"
        Me.lblTrackData1.Size = New System.Drawing.Size(27, 19)
        Me.lblTrackData1.TabIndex = 61
        Me.lblTrackData1.Text = "888"
        Me.lblTrackData1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTrack1
        '
        Me.lblTrack1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblTrack1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTrack1.ForeColor = System.Drawing.Color.Black
        Me.lblTrack1.Location = New System.Drawing.Point(56, 141)
        Me.lblTrack1.Name = "lblTrack1"
        Me.lblTrack1.Size = New System.Drawing.Size(70, 21)
        Me.lblTrack1.TabIndex = 60
        Me.lblTrack1.Text = "Track"
        Me.lblTrack1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTrackData2
        '
        Me.lblTrackData2.BackColor = System.Drawing.Color.Black
        Me.lblTrackData2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTrackData2.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblTrackData2.Location = New System.Drawing.Point(98, 206)
        Me.lblTrackData2.Name = "lblTrackData2"
        Me.lblTrackData2.Size = New System.Drawing.Size(27, 19)
        Me.lblTrackData2.TabIndex = 63
        Me.lblTrackData2.Text = "888"
        Me.lblTrackData2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTrack2
        '
        Me.lblTrack2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblTrack2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTrack2.ForeColor = System.Drawing.Color.Black
        Me.lblTrack2.Location = New System.Drawing.Point(56, 205)
        Me.lblTrack2.Name = "lblTrack2"
        Me.lblTrack2.Size = New System.Drawing.Size(70, 21)
        Me.lblTrack2.TabIndex = 62
        Me.lblTrack2.Text = "Track"
        Me.lblTrack2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTrackData3
        '
        Me.lblTrackData3.BackColor = System.Drawing.Color.Black
        Me.lblTrackData3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTrackData3.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblTrackData3.Location = New System.Drawing.Point(98, 270)
        Me.lblTrackData3.Name = "lblTrackData3"
        Me.lblTrackData3.Size = New System.Drawing.Size(27, 19)
        Me.lblTrackData3.TabIndex = 65
        Me.lblTrackData3.Text = "888"
        Me.lblTrackData3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTrack3
        '
        Me.lblTrack3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblTrack3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTrack3.ForeColor = System.Drawing.Color.Black
        Me.lblTrack3.Location = New System.Drawing.Point(56, 269)
        Me.lblTrack3.Name = "lblTrack3"
        Me.lblTrack3.Size = New System.Drawing.Size(70, 21)
        Me.lblTrack3.TabIndex = 64
        Me.lblTrack3.Text = "Track"
        Me.lblTrack3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSectorSize0
        '
        Me.lblSectorSize0.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblSectorSize0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSectorSize0.ForeColor = System.Drawing.Color.Black
        Me.lblSectorSize0.Location = New System.Drawing.Point(309, 77)
        Me.lblSectorSize0.Name = "lblSectorSize0"
        Me.lblSectorSize0.Size = New System.Drawing.Size(70, 21)
        Me.lblSectorSize0.TabIndex = 38
        Me.lblSectorSize0.Text = "Size"
        Me.lblSectorSize0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSector0
        '
        Me.lblSector0.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblSector0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSector0.ForeColor = System.Drawing.Color.Black
        Me.lblSector0.Location = New System.Drawing.Point(132, 77)
        Me.lblSector0.Name = "lblSector0"
        Me.lblSector0.Size = New System.Drawing.Size(70, 21)
        Me.lblSector0.TabIndex = 32
        Me.lblSector0.Text = "Sector"
        Me.lblSector0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTrack0
        '
        Me.lblTrack0.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblTrack0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTrack0.ForeColor = System.Drawing.Color.Black
        Me.lblTrack0.Location = New System.Drawing.Point(56, 77)
        Me.lblTrack0.Name = "lblTrack0"
        Me.lblTrack0.Size = New System.Drawing.Size(70, 21)
        Me.lblTrack0.TabIndex = 30
        Me.lblTrack0.Text = "Track"
        Me.lblTrack0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboDisk0
        '
        Me.cboDisk0.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cboDisk0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDisk0.FormattingEnabled = True
        Me.cboDisk0.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P"})
        Me.cboDisk0.Location = New System.Drawing.Point(11, 51)
        Me.cboDisk0.Name = "cboDisk0"
        Me.cboDisk0.Size = New System.Drawing.Size(39, 21)
        Me.cboDisk0.TabIndex = 0
        '
        'lblFilename0
        '
        Me.lblFilename0.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblFilename0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilename0.ForeColor = System.Drawing.Color.Black
        Me.lblFilename0.Location = New System.Drawing.Point(56, 51)
        Me.lblFilename0.Name = "lblFilename0"
        Me.lblFilename0.Size = New System.Drawing.Size(515, 21)
        Me.lblFilename0.TabIndex = 1
        Me.lblFilename0.Text = "lblFilename0"
        Me.lblFilename0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSize0
        '
        Me.lblSize0.BackColor = System.Drawing.Color.Black
        Me.lblSize0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSize0.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSize0.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblSize0.Location = New System.Drawing.Point(352, 78)
        Me.lblSize0.Name = "lblSize0"
        Me.lblSize0.Size = New System.Drawing.Size(27, 19)
        Me.lblSize0.TabIndex = 2
        Me.lblSize0.Text = "888"
        Me.lblSize0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTrackData0
        '
        Me.lblTrackData0.BackColor = System.Drawing.Color.Black
        Me.lblTrackData0.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTrackData0.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblTrackData0.Location = New System.Drawing.Point(98, 78)
        Me.lblTrackData0.Name = "lblTrackData0"
        Me.lblTrackData0.Size = New System.Drawing.Size(27, 19)
        Me.lblTrackData0.TabIndex = 31
        Me.lblTrackData0.Text = "888"
        Me.lblTrackData0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSectorData0
        '
        Me.lblSectorData0.BackColor = System.Drawing.Color.Black
        Me.lblSectorData0.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSectorData0.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblSectorData0.Location = New System.Drawing.Point(174, 78)
        Me.lblSectorData0.Name = "lblSectorData0"
        Me.lblSectorData0.Size = New System.Drawing.Size(27, 19)
        Me.lblSectorData0.TabIndex = 33
        Me.lblSectorData0.Text = "888"
        Me.lblSectorData0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRead0
        '
        Me.lblRead0.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblRead0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRead0.ForeColor = System.Drawing.Color.Black
        Me.lblRead0.Location = New System.Drawing.Point(207, 77)
        Me.lblRead0.Name = "lblRead0"
        Me.lblRead0.Size = New System.Drawing.Size(45, 21)
        Me.lblRead0.TabIndex = 34
        Me.lblRead0.Text = "Read"
        Me.lblRead0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblReadData0
        '
        Me.lblReadData0.BackColor = System.Drawing.Color.Black
        Me.lblReadData0.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReadData0.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblReadData0.Location = New System.Drawing.Point(240, 78)
        Me.lblReadData0.Name = "lblReadData0"
        Me.lblReadData0.Size = New System.Drawing.Size(12, 19)
        Me.lblReadData0.TabIndex = 35
        Me.lblReadData0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblWrite0
        '
        Me.lblWrite0.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblWrite0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblWrite0.ForeColor = System.Drawing.Color.Black
        Me.lblWrite0.Location = New System.Drawing.Point(258, 77)
        Me.lblWrite0.Name = "lblWrite0"
        Me.lblWrite0.Size = New System.Drawing.Size(45, 21)
        Me.lblWrite0.TabIndex = 36
        Me.lblWrite0.Text = "Write"
        Me.lblWrite0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWriteData0
        '
        Me.lblWriteData0.BackColor = System.Drawing.Color.Black
        Me.lblWriteData0.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWriteData0.ForeColor = System.Drawing.Color.OrangeRed
        Me.lblWriteData0.Location = New System.Drawing.Point(291, 78)
        Me.lblWriteData0.Name = "lblWriteData0"
        Me.lblWriteData0.Size = New System.Drawing.Size(12, 19)
        Me.lblWriteData0.TabIndex = 37
        Me.lblWriteData0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAPE
        '
        Me.lblAPE.BackColor = System.Drawing.Color.Black
        Me.lblAPE.Font = New System.Drawing.Font("Trebuchet MS", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAPE.ForeColor = System.Drawing.Color.White
        Me.lblAPE.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblAPE.Location = New System.Drawing.Point(503, 0)
        Me.lblAPE.Name = "lblAPE"
        Me.lblAPE.Size = New System.Drawing.Size(78, 42)
        Me.lblAPE.TabIndex = 66
        Me.lblAPE.Text = "ape"
        '
        'lblDiskTypeData0
        '
        Me.lblDiskTypeData0.BackColor = System.Drawing.Color.Black
        Me.lblDiskTypeData0.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiskTypeData0.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblDiskTypeData0.Location = New System.Drawing.Point(12, 78)
        Me.lblDiskTypeData0.Name = "lblDiskTypeData0"
        Me.lblDiskTypeData0.Size = New System.Drawing.Size(27, 19)
        Me.lblDiskTypeData0.TabIndex = 67
        Me.lblDiskTypeData0.Text = "888"
        Me.lblDiskTypeData0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDiskTypeData1
        '
        Me.lblDiskTypeData1.BackColor = System.Drawing.Color.Black
        Me.lblDiskTypeData1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiskTypeData1.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblDiskTypeData1.Location = New System.Drawing.Point(12, 142)
        Me.lblDiskTypeData1.Name = "lblDiskTypeData1"
        Me.lblDiskTypeData1.Size = New System.Drawing.Size(27, 19)
        Me.lblDiskTypeData1.TabIndex = 68
        Me.lblDiskTypeData1.Text = "888"
        Me.lblDiskTypeData1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDiskTypeData2
        '
        Me.lblDiskTypeData2.BackColor = System.Drawing.Color.Black
        Me.lblDiskTypeData2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiskTypeData2.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblDiskTypeData2.Location = New System.Drawing.Point(12, 206)
        Me.lblDiskTypeData2.Name = "lblDiskTypeData2"
        Me.lblDiskTypeData2.Size = New System.Drawing.Size(27, 19)
        Me.lblDiskTypeData2.TabIndex = 69
        Me.lblDiskTypeData2.Text = "888"
        Me.lblDiskTypeData2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDiskTypeData3
        '
        Me.lblDiskTypeData3.BackColor = System.Drawing.Color.Black
        Me.lblDiskTypeData3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiskTypeData3.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblDiskTypeData3.Location = New System.Drawing.Point(12, 270)
        Me.lblDiskTypeData3.Name = "lblDiskTypeData3"
        Me.lblDiskTypeData3.Size = New System.Drawing.Size(27, 19)
        Me.lblDiskTypeData3.TabIndex = 70
        Me.lblDiskTypeData3.Text = "888"
        Me.lblDiskTypeData3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(582, 303)
        Me.Controls.Add(Me.lblDiskTypeData3)
        Me.Controls.Add(Me.lblDiskTypeData2)
        Me.Controls.Add(Me.lblDiskTypeData1)
        Me.Controls.Add(Me.lblDiskTypeData0)
        Me.Controls.Add(Me.lblAPE)
        Me.Controls.Add(Me.lblTrackData3)
        Me.Controls.Add(Me.lblTrack3)
        Me.Controls.Add(Me.lblTrackData2)
        Me.Controls.Add(Me.lblTrack2)
        Me.Controls.Add(Me.lblTrackData1)
        Me.Controls.Add(Me.lblTrack1)
        Me.Controls.Add(Me.lblSectorData3)
        Me.Controls.Add(Me.lblSector3)
        Me.Controls.Add(Me.lblSectorData2)
        Me.Controls.Add(Me.lblSector2)
        Me.Controls.Add(Me.lblSectorData1)
        Me.Controls.Add(Me.lblSector1)
        Me.Controls.Add(Me.lblReadData3)
        Me.Controls.Add(Me.lblRead3)
        Me.Controls.Add(Me.lblReadData2)
        Me.Controls.Add(Me.lblRead2)
        Me.Controls.Add(Me.lblReadData1)
        Me.Controls.Add(Me.lblRead1)
        Me.Controls.Add(Me.lblWriteData3)
        Me.Controls.Add(Me.lblWrite3)
        Me.Controls.Add(Me.lblWriteData2)
        Me.Controls.Add(Me.lblWrite2)
        Me.Controls.Add(Me.lblWriteData1)
        Me.Controls.Add(Me.lblWrite1)
        Me.Controls.Add(Me.lblWriteData0)
        Me.Controls.Add(Me.lblWrite0)
        Me.Controls.Add(Me.lblReadData0)
        Me.Controls.Add(Me.lblRead0)
        Me.Controls.Add(Me.lblSectorData0)
        Me.Controls.Add(Me.lblTrackData0)
        Me.Controls.Add(Me.cboHandshaking)
        Me.Controls.Add(Me.cboStopBits)
        Me.Controls.Add(Me.cboDataBits)
        Me.Controls.Add(Me.cboParity)
        Me.Controls.Add(Me.cboBaudRate)
        Me.Controls.Add(Me.cboCOMPort)
        Me.Controls.Add(Me.btnBoot3)
        Me.Controls.Add(Me.btnBoot2)
        Me.Controls.Add(Me.btnBoot1)
        Me.Controls.Add(Me.btnBoot0)
        Me.Controls.Add(Me.lblSize3)
        Me.Controls.Add(Me.lblSize2)
        Me.Controls.Add(Me.lblSize1)
        Me.Controls.Add(Me.lblSize0)
        Me.Controls.Add(Me.btnNew3)
        Me.Controls.Add(Me.btnNew2)
        Me.Controls.Add(Me.btnNew1)
        Me.Controls.Add(Me.btnNew0)
        Me.Controls.Add(Me.btnOpen3)
        Me.Controls.Add(Me.btnOpen2)
        Me.Controls.Add(Me.btnOpen1)
        Me.Controls.Add(Me.btnOpen0)
        Me.Controls.Add(Me.lblFilename3)
        Me.Controls.Add(Me.lblFilename2)
        Me.Controls.Add(Me.lblFilename1)
        Me.Controls.Add(Me.lblFilename0)
        Me.Controls.Add(Me.cboDisk3)
        Me.Controls.Add(Me.cboDisk2)
        Me.Controls.Add(Me.cboDisk1)
        Me.Controls.Add(Me.cboDisk0)
        Me.Controls.Add(Me.lblTrack0)
        Me.Controls.Add(Me.lblSector0)
        Me.Controls.Add(Me.lblSectorSize0)
        Me.Controls.Add(Me.lblSectorSize1)
        Me.Controls.Add(Me.lblSectorSize2)
        Me.Controls.Add(Me.lblSectorSize3)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(588, 335)
        Me.MinimumSize = New System.Drawing.Size(588, 335)
        Me.Name = "MainForm"
        Me.Text = "Altair Peripheral Emulator"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cboDisk1 As System.Windows.Forms.ComboBox
    Friend WithEvents cboDisk2 As System.Windows.Forms.ComboBox
    Friend WithEvents cboDisk3 As System.Windows.Forms.ComboBox
    Friend WithEvents lblFilename1 As System.Windows.Forms.Label
    Friend WithEvents lblFilename2 As System.Windows.Forms.Label
    Friend WithEvents lblFilename3 As System.Windows.Forms.Label
    Friend WithEvents btnOpen0 As System.Windows.Forms.Button
    Friend WithEvents btnOpen1 As System.Windows.Forms.Button
    Friend WithEvents btnOpen2 As System.Windows.Forms.Button
    Friend WithEvents btnOpen3 As System.Windows.Forms.Button
    Friend WithEvents btnNew0 As System.Windows.Forms.Button
    Friend WithEvents btnNew1 As System.Windows.Forms.Button
    Friend WithEvents btnNew2 As System.Windows.Forms.Button
    Friend WithEvents btnNew3 As System.Windows.Forms.Button
    Friend WithEvents lblSize3 As System.Windows.Forms.Label
    Friend WithEvents lblSize2 As System.Windows.Forms.Label
    Friend WithEvents lblSize1 As System.Windows.Forms.Label
    Friend WithEvents NewFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents btnBoot0 As System.Windows.Forms.Button
    Friend WithEvents btnBoot1 As System.Windows.Forms.Button
    Friend WithEvents btnBoot2 As System.Windows.Forms.Button
    Friend WithEvents btnBoot3 As System.Windows.Forms.Button
    Friend WithEvents cboCOMPort As System.Windows.Forms.ComboBox
    Friend WithEvents cboBaudRate As System.Windows.Forms.ComboBox
    Friend WithEvents cboParity As System.Windows.Forms.ComboBox
    Friend WithEvents cboDataBits As System.Windows.Forms.ComboBox
    Friend WithEvents cboStopBits As System.Windows.Forms.ComboBox
    Friend WithEvents cboHandshaking As System.Windows.Forms.ComboBox
    Friend WithEvents OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents lblSectorSize1 As System.Windows.Forms.Label
    Friend WithEvents lblSectorSize2 As System.Windows.Forms.Label
    Friend WithEvents lblSectorSize3 As System.Windows.Forms.Label
    Friend WithEvents lblWriteData1 As System.Windows.Forms.Label
    Friend WithEvents lblWrite1 As System.Windows.Forms.Label
    Friend WithEvents lblWriteData2 As System.Windows.Forms.Label
    Friend WithEvents lblWrite2 As System.Windows.Forms.Label
    Friend WithEvents lblWriteData3 As System.Windows.Forms.Label
    Friend WithEvents lblWrite3 As System.Windows.Forms.Label
    Friend WithEvents lblReadData1 As System.Windows.Forms.Label
    Friend WithEvents lblRead1 As System.Windows.Forms.Label
    Friend WithEvents lblReadData2 As System.Windows.Forms.Label
    Friend WithEvents lblRead2 As System.Windows.Forms.Label
    Friend WithEvents lblReadData3 As System.Windows.Forms.Label
    Friend WithEvents lblRead3 As System.Windows.Forms.Label
    Friend WithEvents lblSectorData1 As System.Windows.Forms.Label
    Friend WithEvents lblSector1 As System.Windows.Forms.Label
    Friend WithEvents lblSectorData2 As System.Windows.Forms.Label
    Friend WithEvents lblSector2 As System.Windows.Forms.Label
    Friend WithEvents lblSectorData3 As System.Windows.Forms.Label
    Friend WithEvents lblSector3 As System.Windows.Forms.Label
    Friend WithEvents lblTrackData1 As System.Windows.Forms.Label
    Friend WithEvents lblTrack1 As System.Windows.Forms.Label
    Friend WithEvents lblTrackData2 As System.Windows.Forms.Label
    Friend WithEvents lblTrack2 As System.Windows.Forms.Label
    Friend WithEvents lblTrackData3 As System.Windows.Forms.Label
    Friend WithEvents lblTrack3 As System.Windows.Forms.Label
    Friend WithEvents lblSectorSize0 As System.Windows.Forms.Label
    Friend WithEvents lblSector0 As System.Windows.Forms.Label
    Friend WithEvents lblTrack0 As System.Windows.Forms.Label
    Friend WithEvents cboDisk0 As System.Windows.Forms.ComboBox
    Friend WithEvents lblFilename0 As System.Windows.Forms.Label
    Friend WithEvents lblSize0 As System.Windows.Forms.Label
    Friend WithEvents lblTrackData0 As System.Windows.Forms.Label
    Friend WithEvents lblSectorData0 As System.Windows.Forms.Label
    Friend WithEvents lblRead0 As System.Windows.Forms.Label
    Friend WithEvents lblReadData0 As System.Windows.Forms.Label
    Friend WithEvents lblWrite0 As System.Windows.Forms.Label
    Friend WithEvents lblWriteData0 As System.Windows.Forms.Label
    Friend WithEvents lblAPE As System.Windows.Forms.Label
    Friend WithEvents lblDiskTypeData0 As System.Windows.Forms.Label
    Friend WithEvents lblDiskTypeData1 As System.Windows.Forms.Label
    Friend WithEvents lblDiskTypeData2 As System.Windows.Forms.Label
    Friend WithEvents lblDiskTypeData3 As System.Windows.Forms.Label

End Class
