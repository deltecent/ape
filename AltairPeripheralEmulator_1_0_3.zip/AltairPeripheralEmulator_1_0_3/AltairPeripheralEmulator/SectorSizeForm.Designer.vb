<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SectorSizeForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn128 = New System.Windows.Forms.Button
        Me.btn512 = New System.Windows.Forms.Button
        Me.btn512Large = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btn128
        '
        Me.btn128.Location = New System.Drawing.Point(12, 12)
        Me.btn128.Name = "btn128"
        Me.btn128.Size = New System.Drawing.Size(75, 23)
        Me.btn128.TabIndex = 0
        Me.btn128.Text = "&128 Byte FD"
        Me.btn128.UseVisualStyleBackColor = True
        '
        'btn512
        '
        Me.btn512.Location = New System.Drawing.Point(93, 12)
        Me.btn512.Name = "btn512"
        Me.btn512.Size = New System.Drawing.Size(75, 23)
        Me.btn512.TabIndex = 1
        Me.btn512.Text = "&512 byte FD"
        Me.btn512.UseVisualStyleBackColor = True
        '
        'btn512Large
        '
        Me.btn512Large.Location = New System.Drawing.Point(174, 12)
        Me.btn512Large.Name = "btn512Large"
        Me.btn512Large.Size = New System.Drawing.Size(75, 23)
        Me.btn512Large.TabIndex = 2
        Me.btn512Large.Text = "512 byte &HD"
        Me.btn512Large.UseVisualStyleBackColor = True
        '
        'SectorSizeForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(262, 46)
        Me.ControlBox = False
        Me.Controls.Add(Me.btn512Large)
        Me.Controls.Add(Me.btn512)
        Me.Controls.Add(Me.btn128)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(270, 80)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(270, 80)
        Me.Name = "SectorSizeForm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Select Sector Size and Disk Type"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn128 As System.Windows.Forms.Button
    Friend WithEvents btn512 As System.Windows.Forms.Button
    Friend WithEvents btn512Large As System.Windows.Forms.Button
End Class
