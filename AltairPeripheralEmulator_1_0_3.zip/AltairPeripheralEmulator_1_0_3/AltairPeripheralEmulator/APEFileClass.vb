Public Class APEFileClass

    Private mFilename As String
    Private mSectorSize As UInt16
    Private mTracks As Integer
    Private mSectorsPerTrack As Integer
    Private mDiskType As Integer

    Private mTrack As Integer
    Private mSector As Integer

    Private fs As System.IO.FileStream = Nothing
    Private bw As System.IO.BinaryWriter = Nothing
    Private br As System.IO.BinaryReader = Nothing

    Private mDiskTypeLabel As System.Windows.Forms.Label
    Private mTrackLabel As System.Windows.Forms.Label
    Private mSectorLabel As System.Windows.Forms.Label
    Private mReadLabel As System.Windows.Forms.Label
    Private mReadOnColor As System.Drawing.Color
    Private mReadOffColor As System.Drawing.Color
    Private mWriteLabel As System.Windows.Forms.Label
    Private mWriteOnColor As System.Drawing.Color
    Private mWriteOffColor As System.Drawing.Color

    Public Sub New()
        mFilename = ""
        ' Use SectorSize Property to also set; mTracks, mSectorsPerTrack, and mDiskType
        ' Additionally mTrack is set to 0 and mSector is set to 1
        MyClass.SectorSize = 128

        mDiskTypeLabel = Nothing
        mTrackLabel = Nothing
        mSectorLabel = Nothing
        mReadLabel = Nothing
        mReadOnColor = Color.LimeGreen
        mReadOffColor = Color.Black
        mWriteLabel = Nothing
        mWriteOnColor = Color.OrangeRed
        mWriteOffColor = Color.Black
    End Sub

    Public Sub New(ByVal Filename As String)
        mFilename = Filename
        ' Use SectorSize Property to also set; mTracks, mSectorsPerTrack, and mDiskType
        ' Additionally mTrack is set to 0 and mSector is set to 1
        MyClass.SectorSize = 128

        mDiskTypeLabel = Nothing
        mTrackLabel = Nothing
        mSectorLabel = Nothing
        mReadLabel = Nothing
        mReadOnColor = Color.LimeGreen
        mReadOffColor = Color.Black
        mWriteLabel = Nothing
        mWriteOnColor = Color.OrangeRed
        mWriteOffColor = Color.Black
    End Sub

    Public Sub New(ByVal Filename As String, ByVal SectorSize As UInt16)
        mFilename = Filename
        ' Use SectorSize Property to also set; mTracks, mSectorsPerTrack, and mDiskType
        ' Additionally mTrack is set to 0 and mSector is set to 1
        MyClass.SectorSize = SectorSize

        mDiskTypeLabel = Nothing
        mTrackLabel = Nothing
        mSectorLabel = Nothing
        mReadLabel = Nothing
        mReadOnColor = Color.LimeGreen
        mReadOffColor = Color.Black
        mWriteLabel = Nothing
        mWriteOnColor = Color.OrangeRed
        mWriteOffColor = Color.Black
    End Sub

    Public Property Filename() As String
        Get
            Filename = mFilename
        End Get
        Set(ByVal value As String)
            mFilename = value
        End Set
    End Property

    Public Property SectorSize() As UInt16
        Get
            SectorSize = mSectorSize
        End Get
        Set(ByVal value As UInt16) ' Now Disk Type & Sector Size
            Select Case value
                Case 128
                    mTracks = 77 ' 0..76
                    mSectorsPerTrack = 26 ' 1..26
                    MyClass.DiskType = 0 ' 8" Floppy
                Case 512
                    mTracks = 77 ' 0..76
                    mSectorsPerTrack = 8 ' 1..8
                    MyClass.DiskType = 0 ' 8" Floppy
                Case 1536 ' 1024 + 512
                    mTracks = 213 ' 0..212
                    mSectorsPerTrack = 48 ' 1..48
                    MyClass.DiskType = 1024 ' Hard Disk Type 1024
            End Select
            mSectorSize = value
            mTrack = 0
            mSector = 1
        End Set
    End Property

    Public ReadOnly Property Tracks() As Integer
        Get
            Tracks = mTracks
        End Get
    End Property

    Public ReadOnly Property SectorsPerTrack() As Integer
        Get
            SectorsPerTrack = mSectorsPerTrack
        End Get
    End Property

    Public Property DiskType() As Integer ' 0, 1024
        Get
            DiskType = mDiskType
        End Get
        Set(ByVal value As Integer)
            mDiskType = value
            If mDiskTypeLabel IsNot Nothing Then
                Select Case value
                    Case 0 ' 8" Floppy
                        mDiskTypeLabel.Text = "FD"
                    Case 1024 ' Hard Disk Type 1024
                        mDiskTypeLabel.Text = "HD"
                End Select
            End If
        End Set
    End Property

    Public Property Track() As Integer ' 0..Tracks - 1
        Get
            Track = mTrack
        End Get
        Set(ByVal value As Integer)
            mTrack = value
            If mTrackLabel IsNot Nothing Then
                mTrackLabel.Text = mTrack.ToString
            End If
        End Set
    End Property

    Public Property Sector() As Integer ' 1..SectorsPerTrack
        Get
            Sector = mSector
        End Get
        Set(ByVal value As Integer)
            mSector = value
            If mSectorLabel IsNot Nothing Then
                mSectorLabel.Text = mSector.ToString
            End If
        End Set
    End Property

    Public Function Format() As Boolean
        Dim SectorData((SectorSize And 1023) - 1) As Byte
        For Index As Integer = 0 To (SectorSize And 1023) - 1
            SectorData(Index) = 0
        Next
        If Len(Filename) > 0 Then
            Try
                Dim fs As System.IO.FileStream = New System.IO.FileStream(Filename, System.IO.FileMode.Create, System.IO.FileAccess.Write)
                Dim bw As System.IO.BinaryWriter = New System.IO.BinaryWriter(fs)
                Try
                    bw.Write(SectorSize) ' UInt16 - 2 bytes
                    For Track As Integer = 0 To Tracks - 1
                        For Sector As Integer = 1 To SectorsPerTrack
                            'fs.Seek(3 + Track * SectorsPerTrack * (SectorSize And 1023) + (Sector - 1) * (SectorSize And 1023), IO.SeekOrigin.Begin)
                            bw.Write(SectorData)
                        Next Sector
                    Next Track
                    ' ERAse the directory areas...
                    Select Case SectorSize
                        Case 128
                            For Index As Long = &H1A03 To &H1B63 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H1C03 To &H1C63 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H1D03 To &H1E63 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H1F03 To &H1F63 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2003 To &H2163 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2203 To &H2263 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2303 To &H2363 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2403 To &H2463 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2503 To &H2563 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                            For Index As Long = &H2603 To &H2663 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                        Case 512
                            For Index As Long = &H2003 To &H27E3 Step &H20
                                fs.Seek(Index, IO.SeekOrigin.Begin)
                                bw.Write(CByte(&HE5))
                            Next Index
                        Case 1536 ' 1024 + 512
                            'For Index As Long = &H2003 To &H27E3 Step &H20
                            '    fs.Seek(Index, IO.SeekOrigin.Begin)
                            '    bw.Write(CByte(&HE5))
                            'Next Index
                    End Select
                    Format = True ' Format complete
                Catch ex As Exception
                    Format = False ' Could not write file
                End Try
                bw.Close()
            Catch ex As Exception
                Format = False ' Could not create file
            End Try
        Else
            Format = False ' No Filename
        End If
    End Function

    Public Function Open() As Boolean
        If Len(Filename) > 0 Then
            Try
                fs = New System.IO.FileStream(Filename, System.IO.FileMode.Open, System.IO.FileAccess.ReadWrite)
                br = New System.IO.BinaryReader(fs)
                bw = New System.IO.BinaryWriter(fs)
                Try
                    SectorSize = br.ReadUInt16 ' UInt16 - 2 bytes
                    Open = True ' Open complete
                Catch ex As Exception
                    Open = False ' Could not read file
                End Try
                'br.Close()
            Catch ex As Exception
                Open = False ' Could not open file
            End Try
        Else
            Open = False ' No Filename
        End If
    End Function

    Public Sub Close()
        Try
            bw.Close()
            br.Close()
            fs.Close()
        Catch ex As Exception
            ' Ignored
        End Try
    End Sub

    Public Function Write(ByRef SectorData() As Byte) As Boolean
        If mWriteLabel IsNot Nothing Then
            mWriteLabel.ForeColor = mWriteOnColor
        End If
        If mReadLabel IsNot Nothing Then
            mReadLabel.ForeColor = mReadOffColor
        End If
        Try
            fs.Seek(3 + Track * SectorsPerTrack * (SectorSize And 1023) + (Sector - 1) * (SectorSize And 1023), IO.SeekOrigin.Begin)
            bw.Write(SectorData)
            Write = True
        Catch ex As Exception
            Write = False
        End Try
    End Function

    Public Function Read(ByRef SectorData() As Byte) As Boolean
        If mReadLabel IsNot Nothing Then
            mReadLabel.ForeColor = mReadOnColor
        End If
        If mWriteLabel IsNot Nothing Then
            mWriteLabel.ForeColor = mWriteOffColor
        End If
        Try
            fs.Seek(3 + Track * SectorsPerTrack * (SectorSize And 1023) + (Sector - 1) * (SectorSize And 1023), IO.SeekOrigin.Begin)
            SectorData = br.ReadBytes((SectorSize And 1023))
            Read = True
        Catch ex As Exception
            Read = False
        End Try
    End Function

    Public Property DiskTypeLabel() As System.Windows.Forms.Label
        Get
            DiskTypeLabel = mDiskTypeLabel
        End Get
        Set(ByVal value As System.Windows.Forms.Label)
            mDiskTypeLabel = value
        End Set
    End Property

    Public Property TrackLabel() As System.Windows.Forms.Label
        Get
            TrackLabel = mTrackLabel
        End Get
        Set(ByVal value As System.Windows.Forms.Label)
            mTrackLabel = value
        End Set
    End Property

    Public Property SectorLabel() As System.Windows.Forms.Label
        Get
            SectorLabel = mSectorLabel
        End Get
        Set(ByVal value As System.Windows.Forms.Label)
            mSectorLabel = value
        End Set
    End Property

    Public Property ReadLabel() As System.Windows.Forms.Label
        Get
            ReadLabel = mReadLabel
        End Get
        Set(ByVal value As System.Windows.Forms.Label)
            mReadLabel = value
        End Set
    End Property

    Public Property WriteLabel() As System.Windows.Forms.Label
        Get
            WriteLabel = mWriteLabel
        End Get
        Set(ByVal value As System.Windows.Forms.Label)
            mWriteLabel = value
        End Set
    End Property

End Class
